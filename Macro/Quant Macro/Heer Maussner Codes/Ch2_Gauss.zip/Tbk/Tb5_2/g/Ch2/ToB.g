@ -------------------------- Tob.g -----------------------------------------------

  Author: Alfred Maussner

  Purpose: Solve the  time to build model from Heer and Mau�ner, 2nd., edition
           Section 2.6.2

--------------------------------------------------------------------------------- @

new;

library user, dge, pgraph;

/* Parameters */
 load path=d:\tbk\tb5\g\ch2;
 loadeps=1;
 saveeps=0;
    a=1.005;
alpha=0.73;
eta  =2.0;
 beta=0.994;
delta=0.011;
nstar=0.13;
  rho=0.90;
sigma=0.0072;
omega=zeros(4,1);
omega[1:4]=ones(4,1)*.25;

/* stationary solution */
yk=((a^eta)-beta*(1-delta))/(beta*(1-alpha));
yk=yk*(omega[1]+((a^eta)/beta)*omega[2]+(((a^eta)/beta)^2)*omega[3]+ (((a^eta)/beta)^3)*omega[4]);
ck=yk-(a+delta-1)*(omega[1]+a*omega[2]+(a^2)*omega[3]+(a^3)*omega[4]);
kstar=nstar*(yk^(-1/alpha));
ystar=yk*kstar;
cstar=ck*kstar;
istar=ystar-cstar;
wstar=alpha*ystar/nstar;
theta=((1-nstar)/nstar)*alpha*(ystar/cstar);
s1star=(a+delta-1)*kstar;
s2star=a*s1star;
s3star=a*s2star;
s4star=a*s3star;
zstar=0;

ybar=1|kstar|s1star|s2star|s3star|zstar|s4star|nstar;

/* set up the A and B matrix */
amat=zeros(6,6);
amat[1,1]=1.;
amat[2,2]=(1-delta)/a; amat[2,3]=1/a;
amat[3,4]=1/a;
amat[4,5]=1/a;
amat[6,6]=rho; 

bmat=zeros(6,2);
bmat[5,1]=1/a;
cls;

{pf,prec}=SolveLQA(&g,beta*(a^(1-eta)),ybar,Amat,Bmat);
prec;wait;
goto next;

/* Compute impulse responses */
nobs=100;
xt=zeros(6,nobs+1);
ut=zeros(2,nobs);
yt=zeros(nobs,1);
xt[1,1]=1;
xt[2,1]=kstar;
xt[3,1]=s1star;
xt[4,1]=s2star;
xt[5,1]=s3star;
xt[6,1]=zstar+sigma; xt[6,1]=zstar;
evec=zeros(6,1); evec[6]=1;
t=1;
do until t>nobs;
     ut[.,t]=pf*xt[.,t];
   xt[.,t+1]=amat*xt[.,t]+bmat*ut[.,t]+evec*sigma*rndn(1,1);
   yt[t]    =exp(xt[6,t])*(ut[2,t]^alpha)*(xt[2,t]^(1-alpha));
   yt[t]    =(a^t)*yt[t];
           t=t+1;
endo;
dy=ln(yt[2:nobs])-ln(yt[1:nobs-1]);
corrx(dy[2:rows(dy)]~dy[1:rows(dy)-1]);
goto ende;
GraphSettings;
xy(seqa(1,1,nobs),(ut[2,.]'-nstar)/nstar);
xy(seqa(1,1,nobs), (yt-ystar)/ystar);

/* Simulate and print results */
next:
nobs=60;
nofs=500;

{sx,rxy,rx,cnw}=RBCRun(nobs,nofs);

output file=d:\tbk\tb5\g\ch2\ToP_GE_Results.txt reset;
out1="Output  "~" "|
      "Investme"~"nt"|
      "Consumpt"~"ion"|
      "Hours"~""|
      "Real Wag"~"e";
 

 out1=out1~100*sqrt(sx);
 out1=out1~(1.00|rxy);
 out1=out1~rx; 

 mask=(0~0~1~1~1);
 fmt={"-*.*s" 8 8, "-*.*s" 8 8, "*.*lf" 8 2, "*.*lf" 8 2,"*.*lf" 8 2};

 ?"Moments from the linear quadratic solution:";
 i=printfm(out1,mask,fmt); 

 ?"";?"";
 ?"Column 1: Variable Name";
 ?"Column 2: Standard Deviation";
 ?"Column 3: Cross Correlation with Output";
 ?"Column 4: First Order Autocorrelation";

 ?"Crosscorrelation output/investment at lags 1 to 4:";
 ?cnw[.,1]';
 ?"Crosscorrelation wage/hours at lags 1 to 4:";
 ?cnw[.,2]';
 ?"Parameters:";
 ?"a=        " ftos(a,       "%*.*lf",8,4);
 ?"alpha=    " ftos(alpha,   "%*.*lf",8,4);
 ?"delta=    " ftos(delta,   "%*.*lf",8,4);
 ?"rho=      " ftos(rho,     "%*.*lf",8,4);
 ?"sigma=    " ftos(sigma,   "%*.*lf",8,4);
 ?"omega[1]= " ftos(omega[1],"%*.*lf",8,4);
 ?"omega[2]= " ftos(omega[2],"%*.*lf",8,4);
 ?"omega[3]= " ftos(omega[3],"%*.*lf",8,4);
 ?"omega[4]= " ftos(omega[4],"%*.*lf",8,4);
 ?"beta=     " ftos(beta,    "%*.*lf",8,4);
 ?"eta=      " ftos(eta,     "%*.*lf",8,4);
 ?"nstar=    " ftos(nstar,   "%*.*lf",8,4);
 output off; 

ende:
end;


/* ----------------------------------- subroutines ---------------------------------- */

/* g: current period utility function  u(C, 1-N):=ln(C)+theta*ln(1-N)
** where:
**
**  y[1]=constant
**  y[2]=k   
**  y[3]=s1
**  y[4]=s2
**  y[5]=s3
**  y[6]=ln Z
**  y[7]=S4
**  y[8]=N
*/

proc(1)=g(y);

 local c, u;

 c=exp(y[6])*(y[8]^alpha)*(y[2]^(1.-alpha))-omega[1]*y[3]
   -omega[2]*y[4]-omega[3]*y[5]-omega[4]*y[7];

 if eta==1;
    u=ln(c)+theta*ln(1-y[8]);
 else;
    u=(c^(1-eta))*((1-y[8])^(theta*(1-eta)));
    u=u/(1-eta);
 endif;

retp(u);

endp;




/* RBCRun: 
**
** {sx, sxy, rxy, rx}=RBCRun(nobs,nofs);
**
**         Computes  nofs atrifical time series of length nobs.
**
** Output:
**
**  sx: nofs x 5 matrix, columns: standard
**         deviation of output, investment, consumption, hours, and the
**         real wage)
**
**  sxy: nofs x 5 matrix, columns: sx relative to standard deviation of output
**
**  sxy: nofs x 4 matrix, columns: crosscorrelation of investment, consumption,
**                         hours, and the real wage with with output
**
**  rx : nofs x 5 matrix, columns: autocorrelations of first order of
**                        output, investment, consumption, hours, and the real wage
*/
 
proc(4)=RBCRun(nobs,nofs);

   local kt, zt, ct, nt, yt, it, st, wt, itn, eps,
         sx, rxy, rx, mom1,mom2, t, xt, ut, evec, cnw, temp;
   
   sx=zeros(5,1);   
   rxy=zeros(4,1);
   rx=zeros(5,1);   
   cnw=zeros(4,2);

  /* Simulation  */
  if LoadEps;
    load eps;
  else;
    eps=rndn(nobs+1,nofs);
  endif;
  if SaveEps; save eps; endif;
  eps=sigma*eps;
  itn=1;cls; locate 5,5;?"Simulation No. ";
  do until itn>nofs;
  locate 6,5;ftos(itn,"*.*lf",4,0);
  
  /* Initialize vectors: eps is taken from the main program, so that
  ** the long series and the short series are based on the same shocks.
  ** 
  ** To compare the results from Ramsey4c to those of Ramsey4d,
  ** eps is saved to a file eps.fmt so that it can be used in Ramsey4d.
  */ 
  
  kt=zeros(nobs,1);yt=kt; ct=kt; nt=kt; wt=kt; it=kt; zt=kt;
  kt=kstar|kt; 
  zt=(exp(eps[1,itn]))|zt;
  xt=zeros(6,nobs+1);
  ut=zeros(2,nobs);

  xt=zeros(6,nobs+1);
  ut=zeros(2,nobs);

  xt[1,1]=1;
  xt[2,1]=kstar;
  xt[3,1]=s1star;
  xt[4,1]=s2star;
  xt[5,1]=s3star;
  xt[6,1]=zstar+eps[1,itn];
    evec=zeros(6,1); evec[6]=1;

  /* Compute time path */
  t=1;
  do until t>nobs;
     ut[.,t]=pf*xt[.,t];
   xt[.,t+1]=amat*xt[.,t]+bmat*ut[.,t]+evec*eps[t,itn];
   nt[t]    =ut[2,t];
   yt[t]    =exp(xt[6,t])*(ut[2,t]^alpha)*(xt[2,t]^(1-alpha));
   it[t]    =omega[1]*xt[3,t]+omega[2]*xt[4,t]+omega[3]*xt[5,t]+omega[4]*ut[1,t];
   ct[t]    =yt[t]-it[t];
   wt[t]    =alpha*yt[t]/nt[t];
           t=t+1;
endo;

/* HP filtering and computation of second moments */
yt=HPFilter(ln(yt/ystar),1600);
it=HPFilter(ln(it/istar),1600);
ct=HPFilter(ln(ct/cstar),1600);
nt=HPFilter(ln(nt/nstar),1600);
wt=HPFilter(ln(wt/wstar),1600);
temp=corrx(yt[1:nobs-1]~it[2:nobs]);
cnw[1,1]=cnw[1,1]+temp[1,2];
temp=corrx(yt[1:nobs-2]~it[3:nobs]);
cnw[2,1]=cnw[2,1]+temp[1,2];
temp=corrx(yt[1:nobs-3]~it[4:nobs]);
cnw[3,1]=cnw[3,1]+temp[1,2];
temp=corrx(yt[1:nobs-4]~it[5:nobs]);
cnw[4,1]=cnw[4,1]+temp[1,2];

temp=corrx(wt[1:nobs-1]~nt[2:nobs]);
cnw[1,2]=cnw[1,2]+temp[1,2];
temp=corrx(wt[1:nobs-2]~nt[3:nobs]);
cnw[2,2]=cnw[2,2]+temp[1,2];
temp=corrx(wt[1:nobs-3]~nt[4:nobs]);
cnw[3,2]=cnw[3,2]+temp[1,2];
temp=corrx(wt[1:nobs-4]~nt[5:nobs]);
cnw[4,2]=cnw[4,2]+temp[1,2];

    st=(yt~it~ct~nt~wt);
  mom1=vcx(st);  
  mom2=corrx(trimr(st,1,0)~trimr(st,0,1));
  sx=sx+diag(mom1);
  rxy=rxy+mom2[1,2:5]';
  rx=rx+diag(mom2[1:5,6:10]);

  itn=itn+1;

endo;

cnw=cnw/nofs;

retp(sx/nofs,rxy/nofs,rx/nofs,cnw);

endp;


