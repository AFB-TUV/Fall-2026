@ ------------------------------- Ramsey3b.g ------------------
   
   01 NovemberOctober 2007
   Alfred Mau�ner

   Purpose: Compute the quadratic policy function of the
            stochastic growth model as shown in Section 2.5
            of Heer and Mau�ner (2nd ed.)

            The derivatives are computed via numeric
            differentiation.

   Output is written to Ramsey3b.txt.
            
-------------------------------------------------------------- @


new;

library user, pgraph;

/* Parameters */
alpha=0.27;
beta=0.994;
delta=1.0; delta=0.011;
eta=1.0;   eta=2.0;
sigma=0.0072;
rho=0.90;

/* Information for the computation of Euler equation residuals */
zmin=0.95;    @ lower bound on e^z  @
zmax=1.05;    @ upper bound on e^z  @
kmin=0.90;    @ kmin*kstar: lower bound on capital @
kmax=1.10;    @ kmax*kstar: upper bound on capital @
nobs=20;      @ number of grid points in each dimension   @

/* Computation of Jacobian and Hesse matrices */
_CDJac=1;    @ if 0 use the Gauss command gradp instead @
_CDHesse=1;  @ if 0 use the Gauss command hessp instead @

/* Fixed Point */
zstar=0;
sigmastar=0;
kstar=((1-beta*(1-delta))/(alpha*beta))^(1.0/(alpha-1.0));
ystar=kstar^alpha;
cstar=ystar - delta*kstar;

/* Numeric computation of the matrices  */
xstar=(kstar|cstar|zstar|kstar|cstar|zstar);

if not _CDJac;
     gmat=Gradp(&Sys,xstar);    @ uses the Gauss command @
else;
    gmat=CDJac(&Sys,xstar,2);   @ our central difference numerical computation of the Jacobian @
endif;

Dxl=gmat[.,4:5];
Fxl=gmat[.,1:2];
Fz =-gmat[.,3];
Dz =-gmat[.,6];

{Lxx,Lxz,Llx,Llz,Lux,Luz}=SolveLA(0,0,0,Dxl,Fxl,0,0,Dz,Fz,rho,1);

hk_k=Lxx;
hk_z=Lxz;
hc_k=Llx;
hc_z=Llz;

output file=Ramsey3bb.txt reset;
cls;
MyDate;
?"";
?"Linear coefficients:";
?"hk_k= " hk_k;
?"hk_z= " hk_z;
?"hc_k= " hc_k;
?"hc_z= " hc_z;

/* Quadratic Coefficients */
if not _CDHesse;
    hmat1=hessp(&Sys1,xstar);
    hmat2=hessp(&Sys2,xstar);
else;
    hmat1=CDhesse(&Sys1,xstar);
    hmat2=CDhesse(&Sys2,xstar);
endif;

/* hk_kk and hc_kk */
hvec_k=(1|hc_k|hk_k|hc_k*hk_k);
bvec1=zeros(2,1);
bvec1[1]=hvec_k'*hmat1[1|2|4|5,1|2|4|5]*hvec_k;
bvec1[2]=hvec_k'*hmat2[1|2|4|5,1|2|4|5]*hvec_k;
amat=zeros(2,2);
amat[1,1]=Dxl[1,1]+Dxl[1,2]*Fxl[1,1];
amat[2,1]=Dxl[2,1]+Dxl[2,2]*Llx;
amat[1,2]=Fxl[1,2]+Dxl[1,2]*(hk_k^2);
amat[2,2]=Fxl[2,2]+Dxl[2,2]*(hk_k^2);

xvec1=(-bvec1)/amat;
?"";
?"Quadratic coefficients:";
hk_kk=xvec1[1];
hc_kk=xvec1[2];

?"hk_kk= " hk_kk;
?"hc_kk= " hc_kk;

/* hk_kz and hc_kz */
hvec_z=(hc_z|hk_z|hc_k*hk_z+rho*hc_z|1);
bvec2=zeros(2,1);
test=zeros(2,3);
test[1,1]=hvec_k'*hmat1[1|2|4|5,2|4|5|3]*hvec_z;
test[1,2]=Dxl[1,2]*hk_k*hc_kk*hk_z;
test[1,3]=rho*hvec_k'*(hmat1[1|2|4|5,6]);
test[2,1]=hvec_k'*hmat2[1|2|4|5,2|4|5|3]*hvec_z;
test[2,2]=Dxl[2,2]*hk_k*hc_kk*hk_z;
test[2,3]=rho*hvec_k'*(hmat2[1|2|4|5,6]);
bvec2[1]=hvec_k'*hmat1[1|2|4|5,2|4|5|3]*hvec_z+Dxl[1,2]*hk_k*hc_kk*hk_z+rho*hvec_k'*(hmat1[1|2|4|5,6]);
bvec2[2]=hvec_k'*hmat2[1|2|4|5,2|4|5|3]*hvec_z+Dxl[2,2]*hk_k*hc_kk*hk_z+rho*hvec_k'*(hmat2[1|2|4|5,6]);
amat2=zeros(2,2);
amat2[1,1]=Dxl[1,1]+Dxl[1,2]*hc_k;
amat2[2,1]=Dxl[2,1]+Dxl[2,2]*hc_k;
amat2[1,2]=Fxl[1,2]+Dxl[1,2]*rho*hk_k;
amat2[2,2]=Fxl[2,2]+Dxl[2,2]*rho*hk_k;

xvec2=(-bvec2)/amat2;
hk_kz=xvec2[1];
hc_kz=xvec2[2];

?"hk_kz= " hk_kz;
?"hc_kz= " hc_kz;

/* hk_zz and hc_zz */
bvec3=zeros(2,1);
hvec_z=(hc_z|hk_z|hc_k*hk_z+rho*hc_z|1|rho);
bvec3[1]=hvec_z'*hmat1[2|4|5|3|6,2|4|5|3|6]*hvec_z+
         Dxl[1,2]*(2*rho*hk_z*hc_kz+hc_kk*(hk_z)^2);
bvec3[2]=hvec_z'*hmat2[2|4|5|3|6,2|4|5|3|6]*hvec_z+
         Dxl[2,2]*(2*rho*hk_z*hc_kz+hc_kk*(hk_z)^2);
amat3=zeros(2,2);
amat3[1,1]=Dxl[1,1]+Dxl[1,2]*hc_k;
amat3[2,1]=Dxl[2,1]+Dxl[2,2]*hc_k;
amat3[1,2]=Fxl[1,2]+Dxl[1,2]*(rho^2);
amat3[2,2]=Fxl[2,2]+Dxl[2,2]*(rho^2);

xvec3=(-bvec3)/amat3;
hk_zz=xvec3[1];
hc_zz=xvec3[2];
?"hk_zz= " hk_zz;
?"hc_zz= " hc_zz;

/* hk_ss and hc_ss */
bvec4=zeros(2,1);
amat4=zeros(2,2);
amat4[1,1]=Dxl[1,1]+Dxl[1,2]*hc_k;
amat4[2,1]=Dxl[2,1]+Dxl[2,2]*hc_k;
amat4[1,2]=Fxl[1,2]+Dxl[1,2];
amat4[2,2]=Fxl[2,2]+Dxl[2,2];
bvec4[1]=hmat1[5,5]*(hc_z^2)+2*hmat1[5,6]*hc_z + hmat1[6,6]+gmat[1,5]*hc_zz;
bvec4[2]=hmat2[5,5]*(hc_z^2)+2*hmat2[5,6]*hc_z + hmat2[6,6]+gmat[2,5]*hc_zz;

xvec4=(-bvec4)/amat4,;
hk_ss=xvec4[1];
hc_ss=xvec4[2];

?"hk_ss= " hk_ss;
?"hc_ss= " hc_ss;

output off;

/* Compute Euler equations residuals */
kvec=seqa(kmin*kstar,(kmax-kmin)*kstar/(nobs-1),nobs);
zvec=seqa(ln(zmin),(ln(zmax)-ln(zmin))/(nobs-1),nobs);
linear=1;
clear z0, k1;
eer1=Euler(kvec,zvec);
f1=maxc(maxc(abs(eer1)));
linear=0;
eer2=Euler(kvec,zvec);
f2=maxc(maxc(abs(eer2)));
rel=f1/f2;
if not _CDJac;
    EER_Ramsey3b_gradp=f2;
    save EER_Ramsey3b_gradp;
endif;
cls;
output on;
?"";
?"Maximum absolute Euler equation residual from linear policy function=    " f1;
?"Maximum absolute Euler euqation residual from quadratic policy function= " f2;
?"First over second                                                      = " rel;
output off;
ende:
end;

/* ---------------------------- Procedures ------------------- */

/* fx=Sys1(x): returns the rhs of the budget constraint
**             as function of (K[t],C[t],Z[t],K[t+1],C[t+1],Z[t+1])
**
**             x[1]=K[t], 
**             x[2]=C[t],
**             x[3]=Z[t]
**             x[4]=K[t+1],
**             x[5]=C[t+1],
**             x[6]=Z[t+1],
*/

proc(1)=Sys1(x);

    local fx;
    
    fx=x[4]-(1-delta)*x[1] - exp(x[3])*x[1]^alpha + x[2];

    retp(fx);

endp;

/* fx=Sys2(x): returns the rhs of the Euler equation for
**             the optimal next period capital stock.
**             See, Sys1 for the definition of x.
*/

proc(1)=Sys2(x);

    local fx, z;
    
    fx=x[2]^(-eta) - beta*(x[5]^(-eta))*(1-delta+alpha*exp(x[6])*(x[4]^(alpha-1)));

    retp(fx);

endp;


/* fx=Sys(x): returns in the 2 by 1 vector fx the rhs of
**            the two equations that determine the time path
**            of the model. See Sys1 and Sys2.
*/

proc(1)=Sys(x);  

    retp(Sys1(x)|Sys2(x));

endp;

 
/* Policy functions */
fn kl(kbar,zbar)=kstar + hk_k*kbar + hk_z*zbar;
fn cl(kbar,zbar)=cstar + hc_k*kbar + hc_z*zbar;
fn kq(kbar,zbar,sbar) = kstar + hk_k*kbar + hk_z*zbar
                        + 0.5*hk_kk*(kbar^2)
                        + 0.5*hk_zz*(zbar^2)
                        + 0.5*hk_ss*(sbar^2)
                        +     hk_kz*kbar*zbar;
fn cq(kbar,zbar,sbar) = cstar + hc_k*kbar + hc_z*zbar
                        + 0.5*hc_kk*(kbar^2)
                        + 0.5*hc_zz*(zbar^2)
                        + 0.5*hc_ss*(sbar^2)
                        +     hc_kz*kbar*zbar;

/* Euler equation residuals */
proc(1)=Euler(kvec,zvec);

    local n, m, eer, i, j, c0, c1, rhs;
    external proc GH_INT4, GetRhs;
    external matrix z0, k1;

     n=rows(kvec);
     m=rows(zvec);
   eer=zeros(n,m);


    for i (1,n,1);
        for j (1,m,1);
			z0=rho*zvec[j];
            if linear;
                k1=kl(kvec[i]-kstar,zvec[j]-zstar);
                c0=cl(kvec[i]-kstar,zvec[j]-zstar);
            else;
                k1=kq(kvec[i]-kstar,zvec[j]-zstar,sigma);
                c0=cq(kvec[i]-kstar,zvec[j]-zstar,sigma);
            endif;
               rhs=GH_INT4(&GetRhs,sigma);
			   rhs=rhs*beta;
                c1=(rhs^(-1/eta));
			eer[i,j]=(c1/c0)-1;
        endfor;
    endfor;

    retp(eer);

	endp;

/* Rhs of Eulerequation */
proc(1)=GetRhs(x);

 local z1, c2;
 external matrix z0, k1;
	
	z1=z0+x;  @ note that z0=rho*zj @    
    if linear;
        c2=cl(k1-kstar,z1-zstar);       
    else; 
        c2=cq(k1-kstar,z1-zstar,sigma);
    endif;

    retp((c2^(-eta))*(1.-delta+alpha*exp(z1)*(k1^(alpha-1))));

endp;



