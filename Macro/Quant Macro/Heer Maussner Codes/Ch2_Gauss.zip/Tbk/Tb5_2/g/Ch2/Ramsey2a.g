@ ------------------------------- Ramsey2a.g ------------------
   
   03 October 2007
   Alfred Mau�ner

   Purpose: Compute the linear policy function of the
            deterministic growth model as shown in Section 2.1
            of Heer and Mau�ner (2nd ed.)

            if eta=1 and delta=1 the program computes
            and plots the time path of the capital
            stock for both the analytic solution
            K[t+1]=alpha*beta*K[t]^alpha
            and the approximate linear solution
            K[t+1]=lambda1*K[t].

            Note, that f(K)=(1-delta)*K + K^alpha.

   Output is written to Ramsey2a.txt.

-------------------------------------------------------------- @


new;

library user, pgraph;

/* Parameters */
alpha=0.27;
beta=0.994;
delta=1.0;@delta=0.011;@
eta=1.0;  @ eta=2.0;@

k0=0.1;  @ percent of kstar to fix the starting value of K @
nobs=7; @ number of elements in the time path of K @

/* Fixed Point */
kstar=((1-beta*(1-delta))/(alpha*beta))^(1.0/(alpha-1.0));
ystar=kstar^alpha;
cstar=ystar - delta*kstar;

/* Jacobian at the fixed point  */

u1=cstar^(-eta);                         u2=-eta*(cstar^(-eta-1));
f1=1-delta + alpha*(kstar^(alpha-1));    f2=alpha*(alpha-1)*(kstar^(alpha-2));

w=zeros(2,2);
w[1,1]=1.0/beta;
w[1,2]=-1;

w[2,1]=-((u1*f2)/u2);
w[2,2]=1 + ((beta*u1*f2)/u2);

/* Alternatively, compute J numericaly */
xstar=(kstar|cstar|kstar|cstar);
gjac=Gradp(&Sys,xstar);
dxl=gjac[.,3:4];
fxl=gjac[.,1:2];
dz=miss(1,1);
fz=miss(1,1);
rho=miss(1,1);

w2=-inv(dxl)*fxl;
cls;
output file=Ramsey2a.txt reset;
MyDate;
?"W matrix from analytic derivatives:";
?w;
?"";
?"W matrix from numeric derivates:";
?w2;
output off;
?"Press any key to continue";wait;

/* Schur factorization of w */

{smat,tmat}=SchurS(w);

/* Computation of policy functions */ 
tmati=tmat';
h1=smat[1,1];
g1=-tmati[2,1]/tmati[2,2];

output off;
{Lxx,Lxz,Llx,Llz,Lux,Luz}=SolveLA(0,0,0,dxl,fxl,0,0,dz,fz,rho,1);
output on;                      

?"";
?"Coefficients: second column: from analytic derivatives, third colum: from numeric derivatives:";
?"hk_k= " h1 Lxx;
?"hc_k= " g1 Llx;
output off;


/* Simulation */
if eta==1 and delta==1;
    kt=zeros(nobs,2);
    k0=k0*kstar;
    kt[1,1]=k0; kt[1,2]=k0;    
    for t (1,nobs-1,1);
        kt[t+1,1]=alpha*beta*(kt[t,1]^alpha);
        kt[t+1,2]=kstar*(1-h1) + h1*kt[t,2]; 
    endfor;
    kvec_linear=kt[1:rows(kt),2];
    save kvec_linear;
    GraphSettings;
    _plegstr="Analytic Solution\000Linear Approximation";
    _plegctl=(1~5~3~k0);
    _plwidth=7;
    _pltype={6,6};
    _pcolor={0,0};
    _pstype=8;
    _plctrl={0,1};
    xlabel("Period");
    ylabel("Capital");
    xy(seqa(0,1,nobs),kt);
endif;

ende:
end;

/* ---------------------------- Procedures ------------------- */

proc(1)=Sys(x);  @ returs the rhs of equations 2.1 as a function of K[t], C[t], K[t+1], C[t+1] @

 local fx;
 fx=zeros(2,1);

 fx[1]=x[3]-(1-delta)*x[1] - x[1]^alpha + x[2];
 fx[2]=x[2]^(-eta) - beta*(x[4]^(-eta))*(1-delta+alpha*(x[3]^(alpha-1)));

retp(fx);
endp;

 
 