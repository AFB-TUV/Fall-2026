@ ------------------------------ NKPK.g ------------------------------------------

   Date:   14 August 2004
   Author: Alfred Maussner
   

   Purpose: Solve and simulate the model of the new keynesian Phillips curve
            presented in Section 2.43 of Heer/Maussner.

            The solution technique is log-linearization.
  
------------------------------------------------------------------------------- @

/* clear memory */
new;

/* Libraries */
library dge, pgraph;

/* name of the output file */
outfile="d:\\tbk\\tb5\\TeX\\NKPK.txt";

/* parameters */
a=1.005;
alpha=0.73;
beta=0.994;
nstar=0.13;
delta=0.011;
rhoZ=0.90;
sigmaz=0.0072;
eta=2;
kappa=4;
CzuM1=0.84;
mubar=1.0172;
RhoM=0.0;
SigmaM=0.0172;
@SigmaM=0.0;@
clear gam;
phi=0.25;@phi=0;@
mu=1.2;@mu=1.;@
phi=0.75;

/* controls a second run */
lauf=0;

nochmal:

/* computation of the stationary solution */
{yk,ck,xsi,ivec}=GetWg;

/* set up matrices */
{Cu,Cxl,Cz,Dxl,Fxl,Du,Fu,Dz,Fz,Rho}=Makemat;

/* compute policy functions */
{Lxx,Lxz,Llx,Llz,Lux,Luz}=SolveLA(Cu,Cxl,Cz,Dxl,Fxl,Du,Fu,Dz,Fz,rho,2);

/* compute impulse responses */
@goto abhier;@
nobs1=20;
schock=1;  @ Schock=1 (2): real (monetary) shock @
{yt,ct,it,nt,wt,pit,mt,mct}=Impulse(nobs1,schock);

if not lauf;
  y1=yt;
  c1=ct;
  i1=it;
  n1=nt;  
  w1=wt;
 pi1=pit;
  m1=mt;
 dd1=-mct+(1-(1/mu))*yt;

if schock==2; rhoM=0.50; else; phi=0.0; endif;
lauf=1;
goto nochmal;
else;
ddt=-mct+(1-(1/mu))*yt; 
 yt=y1~yt; 
  ct=c1~ct;
  it=i1~it;
  nt=n1~nt;
  wt=w1~wt;
 pit=pi1~pit;
  mt=m1~mt; 
 ddt=dd1~ddt;
endif;

GraphSettings;
_pnumht=0.18;
_paxht=0.18;
_ptitlht=0.20;
_plwidth={10,10};
_pltype={6, 3};

t=seqa(1,1,nobs1);
_ptek="Money3_1.tkf";
_pcolor={0,0};
fonts("Simplex Simgrma");
begwind;
window(2,2,0);
xlabel("Quarter");
ylabel("Percentage Deviation from Trend");
title("Output");
if schock==2; 
  _plegstr="\202\114\202[\202\m\201]=0\000\202\114\202[\202\m\201]=0.5";
else;
  _plegstr="\202\102\201=0.25\000\202\102\201=0.0";
endif;

if phi>0; _plegctl=(1~7~t[5]~maxc(yt[.,1]*100)); else; _plegctl=(1~7~t[7]~0.5*minc(yt[.,2]*100)); endif;
xtics(1,nobs1,1,0);
_pline=(1~6~1~0~nobs1~0~1~0~4);
xy(t,yt*100);
nextwind;
title("Investment");
if phi>0; _plegctl=(1~7~t[5]~maxc(it[.,1]*100)); else; _plegctl=(1~7~t[7]~minc(it[.,2]*100)); endif;
xy(t,it*100);
nextwind;
if phi>0; _plegctl=(1~7~t[5]~0.5*maxc(ct[.,1]*100)); else; _plegctl=(1~7~t[7]~0.5*minc(ct[.,2]*100)); endif;
title("Consumption");
xy(t,ct*100);
nextwind;
title("Inflation");
_plegctl=(1~7~t[7]~maxc(pit[.,1]*100));
xy(t,pit*100);
endwind;
_ptek="Money3_2.tkf";
begwind;
window(2,2,0);
xlabel("Quarter");
ylabel("Percentage Deviation from Trend");
title("Real Wage");@title("Profits");@
xtics(1,nobs1,1,0);
_pline=(1~6~1~0~nobs1~0~1~0~4);
xy(t,wt*100);@xy(t,ddt*100);@
nextwind;
title("Hours");
xy(t,nt*100);
nextwind;
title("EOP Real Money Balances");
xy(t,mt*100);
nextwind;
title("Velocity");
xy(t,(CzuM1*(ct-mt)*100));
endwind;

goto ende;

abhier:

/* Simulation */
nofs=500;
nobs=60;
asec=hsec;  @ get system time @
{sx,sxy,rxy,rx,test}=RBCRUN1(nobs,nofs);
@{sx,sxy,rxy,rx}=RBCRUN(nobs,nofs);@
goto ende;
esec=hsec;  @ get system time @

/* print results */
PrintResults;
load path=d:\tbk\tb5\g\ch2;
load moment2;
TeXOutput;
ende:

end;



/* -------------------------------------- subroutines ------------------------------- */

/* GetWG: computes the stationary solution and related elasticities.
*/

proc(4)=GetWg;

  local yk, ck, cy, xsi, ci, f1, f2, f3, f4, theta;
  external matrix gam;

  yk=(a^eta-beta*(1-delta))/(beta*(1-alpha));

  CzuM1=CzuM1/mubar;  
    
  gam=mubar-beta*(a^(1-eta));
  gam=gam*(1/(kappa*mubar))*(CzuM1^(-(1+kappa)));

  f1=1+gam*(1+kappa)*(CzuM1^kappa);
  f2=1+gam*(CzuM1^kappa);
  f3=1+((1-a-delta)/yk);  
  f4=(1/f3)*(f2/f1);
  
  theta=alpha*(1-nstar)*(1/nstar)*(1/f3);@?"theta benchmark= " theta; wait;@
  theta=alpha*f4*(1-nstar)*(1/nstar);    @?"theta money    = " theta; wait;@
  
  cy=f3/f2;
  ck=cy*yk;

  ci=ck/(a+delta-1);

  xsi=zeros(7,1);
  xsi[1]=kappa*gam*(1+kappa)*(CzuM1^kappa)*(1/f1);
  xsi[2]=(theta*(1-eta)*nstar)/(1-nstar);
  xsi[3]=(theta*(1-eta)-1)*nstar*(1/(1-nstar));
  xsi[4]=kappa*gam*(CzuM1^kappa)*ck;
  xsi[5]=f1*ck;
  xsi[6]=1-beta*(a^(-eta))*(1-delta);
  xsi[7]=kappa*(1+kappa)*gam*(CzuM1^(1+kappa));
  xsi[7]=xsi[7]/(1-kappa*gam*(CzuM1^(1+kappa)));

  ivec=zeros(3,1);
  ivec[1]=yk/(a+delta-1);
  ivec[2]=ci*f1;
  ivec[3]=gam*kappa*ci*(CzuM1^kappa);
  
retp(yk,ck,xsi,ivec);

endp;
   
/* MakeMat: provides the matrices for SolveLA
*/

proc(10)=Makemat;


   /* ut=chut|Nhut|whut|Rhut|yhut|pihut
   ** xt=khut|mhut
   ** lamt=lambdahut|xhut|ghut (for phi>0)
   ** zt=zhut|muhut
   */

   local Cu,Cxl,Cz,Dxl,Fxl,Du,Fu,Dz,Fz,Rho;

   
   Cu=zeros(6,6);
   Cu[1,1]=-eta-xsi[1];    Cu[1,2]=-xsi[2];
   Cu[2,1]=(1-eta);        Cu[2,2]=-xsi[3];     Cu[2,3]=-1;
                           Cu[3,2]=1-alpha;     Cu[3,3]=1;
                           Cu[4,2]=-alpha;                 Cu[4,4]=1;     
                           Cu[5,2]=-alpha*mu;                         Cu[5,5]=1;
                                                                                  Cu[6,6]=1;

   Cxl=zeros(6,5);
                                     Cxl[1,3]=1; Cxl[1,4]=-xsi[1];
                                     Cxl[2,3]=1;
   Cxl[3,1]=1-alpha;                                                 Cxl[3,5]=1;
   Cxl[4,1]=-alpha;                                                  Cxl[4,5]=1;
   Cxl[5,1]=mu*(1-alpha);
                         Cxl[6,2]=1;             Cxl[6,4]=-1;

   Cz=zeros(6,2);
   Cz[3,1]=1;
   Cz[4,1]=1;
   Cz[5,1]=mu;
               Cz[6,2]=1;


   Dxl=zeros(5,5);
   Dxl[1,1]=a;    Dxl[1,2]=-xsi[4];
                                    Dxl[2,3]=-1;
                  Dxl[3,2]=xsi[7];  Dxl[3,3]=-1;
                  Dxl[4,2]=1;

   Fxl=zeros(5,5);
   Fxl[1,1]=delta-1;
                     Fxl[2,3]=1;
                     Fxl[3,3]=1;
                                 Fxl[4,4]=-1;
                                              Fxl[5,5]=(1-phi)*(1-phi*beta*(a^(-eta)));

   Du=zeros(5,6);
   Du[2,4]=xsi[6];
                   Du[3,6]=-1;
                   Du[5,6]=-phi*beta*(a^(-eta));

   Fu=zeros(5,6);
   Fu[1,1]=-xsi[5];        Fu[1,5]=yk;
   Fu[3,1]=xsi[7];
                                       Fu[5,6]=phi;

   Dz=zeros(5,2);
   Fz=zeros(5,2);

   Rho=zeros(2,2);
   Rho[1,1]=RhoZ;
   Rho[2,2]=RhoM;
  
if phi==0;
   Cxl=Cxl[.,1:4];
   Dxl=Dxl[1:4,1:4];
   Fxl=Fxl[1:4,1:4];
   Du =Du[1:4,.];
   Fu =Fu[1:4,.];
   Dz =Dz[1:4,.];
   Fz =Fz[1:4,.];
 endif;

retp(Cu,Cxl,Cz,Dxl,Fxl,Du,Fu,Dz,Fz,Rho);

endp;

                   
/* Impulse: Computes impulse responses to a technolgical
**          and (shock=1) and monetary shock (shock=2)
*/

proc(8)=IMPULSE(nobs,schock);

  local it, ut, t, zt, xt, lmt, sigma;  

  /* 
  **
  ** ut:=chut|Nhut|whut|rhut|yhut|pihut
  **
  ** xt:=khut|mhut
  **
  ** lt:=lambdahut|xhut|ghut (fuer phi>0)
  **
  ** zt:=zhut|muhut
  */    
 
  sigma=sigmaZ|sigmaM;

  ut=zeros(6,nobs);
  xt=zeros(2,nobs+1);
  if phi>0; lmt=zeros(3,nobs); else; lmt=zeros(2,nobs); endif;
  zt=zeros(2,nobs+1);
  
  it=zeros(nobs,1);

  /* compute */
  zt[schock,3]=Sigma[Schock]; @ 1 Standardabweichung in Periode 3 @
  t=3;
   
   do until t>nobs;
      zt[.,t+1]=rho*zt[.,t];
      xt[.,t+1]=lxx*xt[.,t]+lxz*zt[.,t];
      lmt[.,t]=Llx*xt[.,t]+Llz*zt[.,t];
      ut[.,t]=lux*xt[.,t]+luz*zt[.,t];      
      it[t]=ivec[1]*ut[5,t]-ivec[2]*ut[1,t]+ivec[3]*lmt[2,t];      
      t=t+1;
   endo;
  if phi>0;
     retp(ut[5,.]',ut[1,.]',it,ut[2,.]',ut[3,.]',ut[6,.]',lmt[2,.]',lmt[3,.]');
  else;
     retp(ut[5,.]',ut[1,.]',it,ut[2,.]',ut[3,.]',ut[6,.]',lmt[2,.]',zeros(nobs,1));
  endif;
      @   yt   ,   ct   ,it,nt      ,wt      ,pit     , mt      , ghut@
endp;


proc (4)=RBCRUN(nobs,nofs);

   local xt, zt, ut, yt, ct, it, nt, wt, itn, st, t, pit, mt,
         epsz, epsmu, sx, sxy, rxy, rx,
         mom1, mom2, lamt;

  /* 
  **
  **     u:=chut|nhut|whut|rhut|yhut|pihut
  **
  **     x:=khut|mhut
  **
  **     l:=lambdahut|xhut|ghut (falls phi>0)
  **
  **     z:=zhut|muhut
  */
  
  /* Initialize */
   sx=zeros(nofs,7); 
   sxy=zeros(nofs,6);
   rxy=zeros(nofs,6);
   rx=zeros(nofs,7);
   load path=d:\tbk\tb5\g\ch2;
   load epsz, epsmu;
   epsz=sigmaZ*epsz;
   @epsz=sigmaZ*rndn(nobs+1,nofs);@
   @epsmu=rndn(nobs+1,nofs);@
   @save epsmu;@   
   epsmu=sigmaM*epsmu;

  /* Simulate */
  
  itn=1;cls;
  do until itn>nofs;
    locate 5,5;ftos(itn,"*.*lf",4,0);
    
    zt=zeros(2,nobs+1);
    
  @    epsz=sigmaz*rndn(nobs+1,1);zt[1,1]=epsz[1]; @   zt[1,1]=epsz[1,itn];
  @    epsmu=sigmaM*rndn(nobs+1,1);zt[2,1]=epsmu[1];@  zt[2,1]=epsmu[1,itn];
    t=1;
    do until t>nobs;
      zt[.,t+1]=rho*zt[.,t]+(epsz[t+1,itn]|epsmu[t+1,itn]);
      t=t+1;
    endo;
    
    /* Initialize variables */

    xt=zeros(2,nobs+1);ut=zeros(6,nobs);
    if phi>0; lamt=zeros(3,nobs); else; lamt=zeros(2,nobs);endif;
    yt=zeros(nobs,1);ct=yt; nt=yt;it=yt;wt=yt;

    /* compute time path */
    t=1;
    do until t>nobs;
        xt[.,t+1]=Lxx*xt[.,t]+Lxz*zt[.,t];
       lamt[.,t]=Llx*xt[.,t]+Llz*zt[.,t]; 
          ut[.,t]=Lux*xt[.,t]+Luz*zt[.,t];
            it[t]=ivec[1]*ut[5,t]-ivec[2]*ut[1,t]+ivec[3]*lamt[2,t];            
                t=t+1;
    endo;

    /* filtering */
    yt=HPFilter(ut[5,.]',1600);
    nt=HPFilter(ut[2,.]',1600);
    ct=HPFilter(ut[1,.]',1600);
    it=HPFilter(it,1600);
    wt=HPFilter(ut[3,.]',1600);  
   pit=HPFilter(ut[6,.]',1600);
    mt=HPFilter(lamt[2,.]',1600);
    
    st=(yt~ct~it~nt~wt~pit~mt);
   
    mom1=vcx(st);
    mom2=corrx(trimr(st,1,0)~trimr(st,0,1));  
    sx[itn,.]=sqrt(diag(mom1))';
    sxy[itn,.]=sx[itn,2:cols(sx)]./sx[itn,1];
    rxy[itn,.]=mom2[1,2:cols(sx)];
    rx[itn,.]=diag(mom2[1:cols(sx),cols(sx)+1:cols(mom2)])';
    
    itn=itn+1;

  endo;
    
  retp(sx*100,sxy,rxy,rx);

 endp;

/* PrintResults: Output second moments */

proc(0)=PrintResults;

   local out, i, var, j;

   output file=d:\tbk\tb5\g\ch2\NKPK.txt reset;
   datestr(0) "   " timestr(0) " Run time: " etstr(esec-asec);
   ?"";
   ?"Parameters:";
   ?"=====================";
   ?"";
   ?"Preferences:";
   ?"";
   ?"eta  = " ftos(eta,"*.*lf",5,2);
   ?"beta = " ftos(beta,"*.*lf",7,5);
   ?"";
   ?"Technology:";
   ?"";
   ?"alpha = " ftos(alpha,"*.*lf",7,5);
   ?"a     = " ftos(a,"*.*lf",7,5);
   ?"delta = " ftos(delta,"*.*lf",7,5);
   ?"rhoZ  = " ftos(rhoZ,"*.*lf",7,5);
   ?"SigmaZ= " ftos(sigmaZ,"*.*lf",7,5);
   ?"";
   ?"Market structure";
   ?"mu    = " ftos(mu,"*.*lf",7,5);
   ?"phi   = " ftos(phi,"*.*lf",7,5);
   ?"";
   ?"Transactions costs:";
   ?"CzuM1 = " ftos(CzuM1,"*.*lf",7,5);
   ?"kappa = " ftos(kappa,"*.*lf",7,5);   
   ?"gamma = " ftos(gam,  "*.*lf",7,5);
   ?"Money supply:";
   ?"Mu    = " ftos(mubar,"*.*lf",7,5);
   ?"rhoM  = " ftos(rhoM,"*.*lf",7,5);
   ?"sigmaM= " ftos(sigmaM,"*.*lf",7,5);
   ?"";
   ?"";
   ?"";
   ?"Number of simulations:  " ftos(nofs,"*.*lf",4,0);
   ?"Number of observations: " ftos(nobs,"*.*lf",3,0);
   ?"";
   var="Output  "~"        "|
       "Consumpt"~"ion     "|
       "Investme"~"nt      "|
       "Hours   "~"        "|
       "Real Wag"~"e       "|
       "Inflatio"~"n       "|
       "Real Mon"~"ey B.   ";

   Outhlp1(var[1,.],meanc(sx[.,1]),1,1,meanc(rx[.,1]));
   i=zeros(2,2);
   i[1,.]=GetInt( sx[.,1],0.05);
   i[2,.]=GetInt( rx[.,1],0.05);
   Outhlp2(i[1,.],(0~0),(0~0),i[2,.]);

   j=2;
   do until j>rows(var);

     Outhlp1(var[j,.],meanc(sx[.,j]),meanc(sxy[.,j-1]),meanc(rxy[.,j-1]),meanc(rx[.,j]));
     i=zeros(4,2); 
     i[1,.]=GetInt( sx[.,j]  ,0.05);
     i[2,.]=GetInt(sxy[.,j-1],0.05);
     i[3,.]=GetInt(rxy[.,j-1],0.05);
     i[4,.]=GetInt( rx[.,j]  ,0.05);
     Outhlp2(i[1,.],i[2,.],i[3,.],i[4,.]);
     j=j+1;

  endo;
  ?"";?"";
  ?"Column 1: Variable";
  ?"Column 2: Standard deviation";
  ?"Column 3: Standard deviation relative to standard deviation of output";
  ?"Column 4: Crosscorrelation with output";
  ?"Column 5: First order autocorrelation";
  

output off;
   
output off;
retp;
endp;
  
proc(0)=Outhlp1(s,n1,n2,n3,n4);

  local out;
  out=strput(s[2],s[1],9)
      $+"    "
      $+ftos(n1,"*.*lf",4,2)
      $+"           "
      $+ftos(n2,"*.*lf",4,2)
      $+"           "
      $+ftos(n3,"*.*lf",4,2)
      $+"           "
      $+ftos(n4,"*.*lf",4,2);
  $out;
retp;
endp;

proc(0)=Outhlp2(i1,i2,i3,i4);

  local out;
  
  out="                " $+ ftos(i1[1],"(*.*lf",4,2) $+"-" $+ftos(i1[2],"*.*lf)",4,2)$+"    "
                         $+ ftos(i2[1],"(*.*lf",4,2) $+"-" $+ftos(i2[2],"*.*lf)",4,2)$+"    "
                         $+ ftos(i3[1],"(*.*lf",4,2) $+"-" $+ftos(i3[2],"*.*lf)",4,2)$+"    "
                         $+ ftos(i4[1],"(*.*lf",4,2) $+"-" $+ftos(i4[2],"*.*lf)",4,2);
  $out;
retp;
endp;
 

proc(0)=TexOutput;
 local out, i,j, fmt1,fmt2,mask;

out="Producti"~"on   "|
    "Consumpt"~"ion  "|
    "Investme"~"nt   "|
    "Hours   "~"     "|
    "Real Wag"~"e    "|
    "Inflatio"~"n    ";
sx=meanc(sx);        sx=sx[1:rows(sx)-1];
rxy=1.0|meanc(rxy); rxy=rxy[1:rows(rxy)-1];
rx=meanc(rx);       rx=rx[1:rows(rx)-1];

out=out~sx~rxy~rx;

mask=0~0~1~1~1~0;

fmt1={"-*.*s" 8 8,"-*.*s&" 8 8,"*.*lf&"   6 2,"*.*lf&"   6 2,"*.*lf"   6 2,"*.*s" 8 8};
fmt2={"-*.*s" 8 8,"-*.*s&" 8 8,"(*.*lf)&" 6 2,"(*.*lf)&" 6 2,"(*.*lf)" 6 2,"*.*s" 8 8};

if mu==1;
  output file=d:\tbk\tb5\g\ch2\NPK0.TeX reset;
else;
  if SigmaM==0;
    output file=d:\tbk\tb5\g\ch2\NKPK1.TeX reset;
  else;
    output file=d:\tbk\tb5\g\ch2\NKPK2.TeX reset;
  endif;
endif;
i=1;
do until i>rows(out);
   j=printfm(out[i,.]~"\\\\\l",mask,fmt1);
   j=printfm(" "~" "~moment2[i,3:cols(moment2)]~"\\\\\l",mask,fmt2);
   i=i+1;
endo;
output off;
retp;
endp;


proc (5)=RBCRUN1(nobs,nofs);

   local xt, zt, ut, yt, ct, it, nt, wt, itn, st, t, pit, mt,
         epsz, epsmu, sx, sxy, rxy, rx,
         mom1, mom2, lamt, test;

  /* 
  **
  **     u:=chut|nhut|whut|rhut|yhut|pihut
  **
  **     x:=khut|mhut
  **
  **     l:=lambdahut|xhut|ghut (falls phi>0)
  **
  **     z:=zhut|muhut
  */
  
  /* Initialize */
   sx=zeros(nofs,7); sx=zeros(nofs,8); test=zeros(8,8);
   sxy=zeros(nofs,6);sxy=zeros(nofs,7);
   rxy=zeros(nofs,6);rxy=zeros(nofs,7);
   rx=zeros(nofs,7);rx=zeros(nofs,8);
   @load epsz;@
   @epsz=sigmaZ*epsz;@
   epsz=sigmaZ*rndn(nobs+1,nofs);
   epsmu=rndn(nobs+1,nofs);
   save epsmu;
   epsmu=sigmaM*epsmu;

  /* Simulate */
  
  itn=1;cls;
  do until itn>nofs;
    locate 5,5;ftos(itn,"*.*lf",4,0);
    
    zt=zeros(2,nobs+1);
    
  @    epsz=sigmaz*rndn(nobs+1,1);zt[1,1]=epsz[1]; @   zt[1,1]=epsz[1,itn];
  @    epsmu=sigmaM*rndn(nobs+1,1);zt[2,1]=epsmu[1];@  zt[2,1]=epsmu[1,itn];
    t=1;
    do until t>nobs;
      zt[.,t+1]=rho*zt[.,t]+(epsz[t+1,itn]|epsmu[t+1,itn]);
      t=t+1;
    endo;
    
    /* Initialize variables */

    xt=zeros(2,nobs+1);ut=zeros(6,nobs);
    if phi>0; lamt=zeros(3,nobs); else; lamt=zeros(2,nobs);endif;
    yt=zeros(nobs,1);ct=yt; nt=yt;it=yt;wt=yt;

    /* compute time path */
    t=1;
    do until t>nobs;
        xt[.,t+1]=Lxx*xt[.,t]+Lxz*zt[.,t];
       lamt[.,t]=Llx*xt[.,t]+Llz*zt[.,t]; 
          ut[.,t]=Lux*xt[.,t]+Luz*zt[.,t];
            it[t]=ivec[1]*ut[5,t]-ivec[2]*ut[1,t]+ivec[3]*lamt[2,t];            
                t=t+1;
    endo;

    /* filtering */
    yt=HPFilter(ut[5,.]',1600);
    nt=HPFilter(ut[2,.]',1600);
    ct=HPFilter(ut[1,.]',1600);
    it=HPFilter(it,1600);
    wt=HPFilter(ut[3,.]',1600);  
   pit=HPFilter(ut[6,.]',1600);
    mt=HPFilter(lamt[2,.]',1600);
    
    st=(yt~ct~it~nt~wt~pit~mt~xt[1,1:nobs]');
   
    mom1=vcx(st);
    mom2=corrx(trimr(st,1,0)~trimr(st,0,1));  
    sx[itn,.]=sqrt(diag(mom1))';
    sxy[itn,.]=sx[itn,2:cols(sx)]./sx[itn,1];
    rxy[itn,.]=mom2[1,2:cols(sx)];
    rx[itn,.]=diag(mom2[1:cols(sx),cols(sx)+1:cols(mom2)])';
    test=test+vcx(st);
    itn=itn+1;

  endo;
    
  retp(sx*100,sxy,rxy,rx,test);

 endp;

