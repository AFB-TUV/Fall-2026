@ ------------------------------- Ramsey2b.g ------------------
   
   03 October 2007
   Alfred Mau�ner

   Purpose: Compute second order approximation
            of the policy function of the
            deterministic growth model as shown in Section 2.5
            of Heer and Mau�ner (2nd ed.)

            if eta=1 and delta=1 the program computes
            and plots the policy function for both the analytic solution
            K[t+1]=alpha*beta*K[t]^alpha
            and the approximate second order solution.
           
            Note, that f(K)=(1-delta)*K + K^alpha.

   Output is written to Ramsey2b.txt


-------------------------------------------------------------- @


new;

library user, pgraph;

/* Parameters */
alpha=0.27;
beta=0.994;
delta=1.0; @ delta=0.011;@
eta=1.0;   @ eta=2;      @

/* Fixed Point */
kstar=((1-beta*(1-delta))/(alpha*beta))^(1.0/(alpha-1.0));
ystar=kstar^alpha;
cstar=ystar - delta*kstar;

/* Computation from analytic derivatives */
/* Jacobian at the fixed point  */
u1=cstar^(-eta);               u2=-eta*(cstar^(-eta-1));
f1=(1-delta) + alpha*(kstar^(alpha-1));    f2=alpha*(alpha-1)*(kstar^(alpha-2));

w=zeros(2,2);
w[1,1]=1.0/beta;
w[1,2]=-1;

w[2,1]=-((u1*f2)/u2);
w[2,2]=1 + ((beta*u1*f2)/u2);

/* Schur factorization of w */
{smat,tmat}=SchurS(w);

/* Computation of policy functions */ 
tmati=tmat';
h1=smat[1,1];
g1=-tmati[2,1]/tmati[2,2];

/* Matrices for second order coefficients */
amat=zeros(2,2);
bvec=zeros(2,1);
amat[1,1]=1;
amat[1,2]=1;
bvec[1]=alpha*(alpha-1)*(kstar^(alpha-2));

amat[2,1]=eta*cstar*g1+alpha*beta*(1-alpha)*(cstar^2)*(kstar^(alpha-2));
amat[2,2]=eta*cstar*((h1^2)-1);
bvec[2]=eta*(1+eta)*(g1^2)*((h1^2)-1)+
2*eta*alpha*beta*(1-alpha)*cstar*(kstar^(alpha-2))*g1*(h1^2)
+alpha*beta*(1-alpha)*(2-alpha)*(cstar^2)*(kstar^(alpha-3))*(h1^2);

xvec1=LSolve(amat,bvec);

ha1=h1; ga1=g1; ha2=xvec1[1]; ga2=xvec1[2];

/* Alternatively, use numeric derivatives */
xstar=(kstar|cstar|kstar|cstar);
JSys=Gradp(&Sys,xstar);
Dxl=JSys[.,3:4];
Fxl=JSys[.,1:2];
Dz=miss(1,1);
Fz=miss(1,1);
rho=miss(1,1);

output file=Ramsey2b_test2.txt reset;
MyDate;
?"alpha= " alpha;
?"beta=  " beta;
?"eta=   " eta;
?"delta= " delta;
?"";
{Lxx,Lxz,Llx,Llz,Lux,Luz}=SolveLA(0,0,0,Dxl,Fxl,0,0,dz,fz,rho,1);
output off;
h1mat=Hessp(&Sys1,xstar);
h2mat=Hessp(&Sys2,xstar);
hvec=(1|Llx|Lxx|Lxx*Llx);
bvec=hvec'*h1mat*hvec;
bvec=bvec|(hvec'*h2mat*hvec);
amat[1,1]=JSys[1,3]+JSys[1,4]*Llx;
amat[1,2]=JSys[1,2]+JSys[1,4]*(Lxx^2);
amat[2,1]=JSys[2,3]+JSys[2,4]*Llx;
amat[2,2]=JSys[2,2]+JSys[2,4]*(Lxx^2);

xvec2=(-bvec)/amat;

hn1=Lxx; gn1=Llx; hn2=xvec2[1]; gn2=xvec2[2];

cls;
output on;
?"";
?"Compare Solutions: Second Column: Analytic Derivatives, Third Column: Numeric Derivatives";
?"hkk = " h1 Lxx;
?"hck = " g1 Llx;
?"hkkk= " xvec1[1] xvec2[1];
?"hckk= " xvec1[2] xvec2[2];
?"";
output off;

/* Plot policy function for consumption */
if eta==1 and delta==1;
    cvec=zeros(100,3);
    kvec=seqa(0.5*kstar,kstar/99,100);     
    cvec[.,1]=(1-alpha*beta)*kvec^alpha;
    cvec[.,2]=cstar+g1*(kvec-kstar);
    cvec[.,3]=cstar+g1*(kvec-kstar)+0.5*xvec1[2]*(kvec-kstar)^2;
    
    GraphSettings;
    _plwidth=7;
    _pltype={6 3 1};
    _pcolor={0,0,0};
    _plegstr="Analytic Solution\000Linear Approximation\000Quadratic Approximation";
    _plegctl=(1~5~1~cvec[1,1]/cstar);
    xlabel("Capital: K/K[*");
    ylabel("Consumption: C/C[*");
    xy(kvec/kstar,cvec/cstar);
endif;
    
kvec=seqa(0.9*kstar,0.2*kstar/199,200);

euler=EER(kvec);
output on;
?"";
?"Euler equation residuals:";
?"From linear policy function with analytic Jacobian:";
?maxc(abs(Euler[.,1]));
?"From linear policy function with numeric Jacobian:";
?maxc(abs(Euler[.,2]));
?"From quadratic policy function with analytic derivatives:";
?maxc(abs(Euler[.,3]));
?"From quadratic policy function with numeric derivatives:";
?maxc(abs(Euler[.,4]));
?"Linear analytic to quadratic analytic:";
?maxc(abs(Euler[.,1]))/maxc(abs(Euler[.,3]));
?"Linear numeric  to quadratic numeric:";
?maxc(abs(Euler[.,2]))/maxc(abs(Euler[.,4]));
?"Numeric linear to analytic linear";
?maxc(abs(Euler[.,2]))/maxc(abs(Euler[.,1]));
?"Numeric quadratic to analytic quadratic:";
?maxc(abs(Euler[.,4]))/maxc(abs(Euler[.,3]));
output off;

ende:
end;

/* ---------------------------- Procedures ------------------- */


proc(1)=Sys1(x); @ returns the rhs of equation 2.1a as a function of K[t], C[t], K[t+1], C[t+1] @

    local fx;
    fx= x[3]-(1-delta)*x[1] - x[1]^alpha + x[2];

retp(fx);

endp;

proc(1)=Sys2(x);  @ returns the rhs of equations 2.1b as a function of K[t], C[t], K[t+1], C[t+1] @

 local fx;
 fx=x[2]^(-eta) - beta*(x[4]^(-eta))*(1-delta+alpha*(x[3]^(alpha-1)));

retp(fx);
endp;

proc(1)=Sys(x);  @ returns both rhs @

   retp(Sys1(x)|Sys2(x));

endp;

/* Policy functions */
 
fn ha(k)=kstar+ha1*(k-kstar)+0.5*ha2*((k-kstar)^2);
fn hn(k)=kstar+hn1*(k-kstar)+0.5*hn2*((k-kstar)^2);
fn ga(k)=cstar+ga1*(k-kstar)+0.5*ga2*((k-kstar)^2);
fn gn(k)=cstar+gn1*(k-kstar)+0.5*gn2*((k-kstar)^2);
fn hla(k)=kstar+ha1*(k-kstar);
fn gla(k)=cstar+ga1*(k-kstar);
fn hln(k)=kstar+hn1*(k-kstar);
fn gln(k)=cstar+gn1*(k-kstar);


proc(1)=EER(kvec,);

    local n,k1,c1,c2,c3, rhs, euler;
    
    n=rows(kvec);
    euler=zeros(n,4);

    for i  (1,n,1);
        k1=hln(kvec[i]);
        c1=gln(kvec[i]);
        c2=gln(k1);
       rhs=beta*(c2^(-eta))*(1-delta+alpha*(k1^(alpha-1)));
        c3=rhs^(-1/eta);
     euler[i,1]=(c3/c1)-1;

        k1=hla(kvec[i]);
        c1=gla(kvec[i]);
        c2=gla(k1);
       rhs=beta*(c2^(-eta))*(1-delta+alpha*(k1^(alpha-1)));
        c3=rhs^(-1/eta);
     euler[i,2]=(c3/c1)-1;

        k1=ha(kvec[i]);        
        c1=ga(kvec[i]);        
        c2=ga(k1);        
       rhs=beta*(c2^(-eta))*(1-delta+alpha*(k1^(alpha-1)));
        c3=rhs^(-1/eta);
        euler[i,3]=(c3/c1)-1;

        k1=hn(kvec[i]);
        c1=gn(kvec[i]);
        c2=gn(k1);

        rhs=beta*(c2^(-eta))*(1-delta+alpha*(k1^(alpha-1)));
        c3=rhs^(-1/eta);
        euler[i,4]=(c3/c1)-1;

    endfor;

retp(euler);

endp;
