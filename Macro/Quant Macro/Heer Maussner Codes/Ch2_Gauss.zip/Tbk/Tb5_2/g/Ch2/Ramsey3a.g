@ ------------------------------- Ramsey3a.g ------------------
   
   03 October 2007
   Alfred Mau�ner

   Purpose: Compute the linear policy function of the
            stochastic growth model as shown in Section 2.1
            of Heer and Mau�ner (2nd ed.)

            if eta=1 and delta=1 the program computes
            histograms from a simulation using
            the true and the linear policy function,
            respectively.            

-------------------------------------------------------------- @


new;

library user, pgraph;

/* Parameters */
alpha=0.27;
beta=0.994;
delta=1.0;
zmin=0.95;    @ lower bound on z in the uniform distribution case  @
zmax=1.05;    @ upper bound on z in the uniform distribution case  @
nobs=1000000; @ length of time path                                @
eta=1.0;
rho=0;
eta=2;
delta=0.011;
rho=0.90;

/* Fixed Point */
zstar=1;
kstar=((1-beta*(1-delta))/(alpha*beta))^(1.0/(alpha-1.0));
ystar=kstar^alpha;
cstar=ystar - delta*kstar;

/* Analytic formulas for the matrices */

u1=cstar^(-eta);               u2=-eta*(cstar^(-eta-1));
f1=1-delta + alpha*(kstar^(alpha-1));    f2=alpha*(alpha-1)*(kstar^(alpha-2));

wmat1=zeros(2,2);
wmat1[1,1]=1/beta;
wmat1[1,2]=-1;
wmat1[2,1]=-(u1*f2)/u2;
wmat1[2,2]=1+ (beta*u1*f2/u2);

rmat1=zeros(2,1);
rmat1[1]=ystar;
rmat1[2]=-(beta*u1*ystar*f2+rho*u1)/u2;

/*  Policy functions */
{smat,tmat}=SchurS(wmat1);
lambda=diag(smat);
tmats=tmat';
q=tmats*rmat1;
Lck=-tmats[2,1]/tmats[2,2];
Lcz=-(q[2]/lambda[2])/(tmats[2,2]*(1-(rho/lambda[2])));

Lkk=(1.0/beta)-Lck;
Lkz=ystar-Lcz;

/* Numeric computation of the matrices  */

xstar=(kstar|cstar|zstar|kstar|cstar|zstar);
amat=Gradp(&Sys,xstar);

Dxl=amat[.,4:5];
Fxl=amat[.,1:2];
Fz =-amat[.,3];
Dz =-amat[.,6];

cls;
{Lxx,Lxz,Llx,Llz,Lux,Luz}=SolveLA(0,0,0,Dxl,Fxl,0,0,Dz,Fz,rho,1);
output file=Ramsey3a.txt reset;
?"Compare Coefficients: Left column: analytic derivatives, right column numeric derivatives";
?"LKK: "  Lkk Lxx;
?"LKZ: "  Lkz Lxz;
?"LCK: "  Lck Llx;
?"LCZ: "  Lcz Llz;
?"";
?"Coefficients of analtytic solution: ";
?"alpha*beta   = " alpha*beta;
?"1-alpha*beta = " (1-alpha*beta);
save Lxx, Lxz; goto ende;
output off;
goto ende;

/* Simulation */
if eta==1 and delta==1;
load F1_5_kvec, F1_5_yvec;
yvec=F1_5_yvec;
kvec=zeros(nobs,2);
kvec[.,1]=F1_5_kvec;
kvec[1,2]=kstar;

for i (1,nobs-1,1);
    @kvec[i+1,1]=alpha*beta*yvec[i]*(kvec[i,1]^alpha);@
    kvec[i+1,2]=kstar-LKK*kstar-LKZ*zstar+LKK*kvec[i,2]+LKZ*yvec[i];
endfor;

{b1,m1,freq1}=hist(kvec[.,2],100);
{b2,m2,freq2}=hist(kvec[.,1],b1);

GraphSettings;

window(1,1,1);
@setwind(1);@
xlabel("Capital Stock");
ylabel("Frequency in Percent");
_pxpmax=3;
_pxsci=2;
_pbartyp={6 7};
@xtics(0.154,0.177,0.005,0);@
histf(100*(freq1./nobs),m1);
@setwind(2);@
@xtics(0.154,0.177,0.005,0);@
_pbartyp={0  0};
histf(100*(freq2./nobs),m2);
endwind;
endif;
ende:
end;

/* ---------------------------- Procedures ------------------- */

/* fx=Sys(x): returns in the 2 by 1 vector fx the rhs of
**            the two equations that determine the time path
**            of the model. The first equation is the economy's
**            resource constraint K[t+1]-(1-delta)*K[t]-Z[t]*K[t]^alpha - C[t]=fx[1].
**            The second equation is the Euler equation for next period's
**            capital stock
**            C[t]^(-eta)-beta*C[t+1]^(-eta)*(1-delta+alpha*Z[t+1]*K[t+1]^(alpha-1))=fx[2].
**
**            The procedure receives x=[K[t],C[t],Z[t],K[t+1],C[t+1],Z[t+1]]'.
**          
*/

proc(1)=Sys(x);  

 local fx;
 fx=zeros(2,1);
 
 fx[1]=x[4]-(1-delta)*x[1] - x[3]*x[1]^alpha + x[2];
 fx[2]=x[2]^(-eta) - beta*(x[5]^(-eta))*(1-delta+alpha*x[6]*(x[4]^(alpha-1)));

retp(fx);
endp;

 
 