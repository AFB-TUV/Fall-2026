Gauss Computer Programs Chapter 2,
2nd edition Heer/Maussner, Dynamic General Equilibrium Modeling
===============================================================

The files
       
NKPK.g                                  
Ramsey2a.g                          
Ramsey2b.g                
Ramsey3a.g                           
Ramsey3b.g                
SolveLA.src               
SolveLQA.src              
SolveQA.src               
ToB.g                     
Tools.dll
DFORRT.dll

store various programs referred to in Chapter 2 of the book.

The routines that compute linear policy rules are in SolveLA.src and
SolveLQA.src (the linear-quadratic model). The routines in SolveQA.src
compute quadratic policy functions. To use these routines either place
a #include filename command at the top of the files where these routines
are referenced or include the procedures in your user.lcg library.

In order to use the procedure SolveLA2 in SolveLA.src you must extract and
copy the file Tools.dll into the Gauss \dlib subdirectory. In addition, you
must extract DFORRT.dll to the Windows\system32 subdirectory.

The programs run under Gauss 7.0 and higher.

In case you have any questions please contact me at 

alfred.maussner@wiwi.uni-augsburg.de

