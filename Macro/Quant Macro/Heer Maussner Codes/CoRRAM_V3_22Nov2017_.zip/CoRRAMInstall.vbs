'CoRRAMInstall.vbx
'Alfred Maußner
'Zweck: Installieren von CoRRAM Version 3
'Revisionen:
'10. Oktober 2017, erste Version

'Deklaration der Variablen
Option Explicit
Dim FSO, Quelle, Ziel, Version, Inhalt1, Inhalt2, Datei1, Datei2, Text, Zeile
Const ForReading=1
Const ForWriting=2

'Abfragen von Quell- und Zielverzeichnis
Quelle=InputBox("CoRRAM Quellverzeichnis eingeben", "Abfragen")
Ziel=InputBox("Gauss Installationsverzeichnis eingeben","Abfragen")

'Überprüfen, ob beide Verzeichnisse existieren
Set FSO=CreateObject("Scripting.FileSystemObject")
if ( FSO.FolderExists(Quelle) And FSO.FolderExists(Ziel)) then

    ' Anlegen von CoRRAM.lcg:
    Datei1=Quelle&"\CoRRAM.lcg"
    Datei2=Ziel&"\lib"&"\CoRRAM.lcg"
    Set Inhalt1=FSO.OpenTextFile(Datei1,ForReading)
    Set Inhalt2=FSO.CreateTextFile(Datei2,True)
    Do until Inhalt1.atEndofStream
            Zeile=Inhalt1.Readline
            if (InStr(1,Zeile,".src")>0 Or InStr(1,Zeile,".dec")>0 Or Instr(1,Zeile,".sdf")>0) then
                Text=Quelle&"\"&Trim(Zeile)
                Zeile=Replace(Zeile,Zeile,Text)
            end if
            Inhalt2.WriteLine(Zeile)
    Loop
    Inhalt1.close
    Inhalt2.close
    
    'Umbenennen von Plot, falls Version kleiner als 16
    'Abfragen der Gaussversionsnummer
    Version=InputBox("Gaussversion eingeben", "Abfragen")
    
    if Version<16 then
        Datei1=Quelle&"\Plot.src"
        Set Inhalt1=FSO.GetFile(Datei1)        
        Datei2=Quelle&"\Plot_new.src"
        Inhalt1.Name=Datei2
        Datei2=Quelle&"\Plot_old.src"
        Inhalt1=FSO.GetFile(Datei2)
        Inhalt1.Name=Datei1        
    end if
    'Abfragen der Gauss bit-Version und kopieren der dll Datei
    'Version=InputBox("Windows 32 oder  64 bit?","Abfragen")
    Version=MsgBox("Gauss 64 bit?",vbYesNo,"Abfrage")
    if Version then
        Datei1=Quelle&"\Tools_64.dll"
    else
        Datei1=Quelle&"\Tools_32.dll"
    end if            
    Datei2=Ziel&"\dlib"&"\Tools.dll"
    FSO.CopyFile Datei1, Datei2 
    WScript.Echo "Installation von CoRRAM erfolgreich beendet"        
        
else
    WScript.Echo "Quell- und/oder Zielverzeichnis nicht vorhanden"    
end if
