Please read the installation instructions in Corram_V3_UG.pdf.

For user of Mac notebooks:

Before you install the files, please run the programm LU_Test.g.
If you encounter a Gauss error message, then

a) rename CoRRAM_4.src to CoRRAM_4_win.src
b) rename CoRRAM_4_mac.src to CoRRAM_4.src
c) install CoRRA_4.src along with the other files as explained in the user's manual.