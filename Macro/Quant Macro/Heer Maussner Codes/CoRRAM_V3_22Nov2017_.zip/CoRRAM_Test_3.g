@ ---------------------------------------- CoRRAM_Test_3.g -----------------------------------------

    Alfred Maussner
	Revisions: 1 October 2013, first version
              22 April   2017, adapted to CoRRAM version 3

    Purpose: Solve and simulate the benchmark business cycle model with
	         a difference stationary growth process. The user must imput the model's equations.
			 
			 
             Note, the first element in the vector that collects the not predetermined
			 variables must be the growth factor a! (See the CoRRAM manual).
			 
--------------------------------------------------------------------------------------------------- @

/* Do not change the next lines of code: *************/

new;
library corram;
struct Variable _Var;

/*****************************************************/    

// Change default settings
_DS=1;

//MakeShocks(3,80,500); you must run this once before you can _LoadShocks=1;

// Create model environment
nx=1; @ xt=[k] @
ny=8; @ yt=[a, y,c,i,n,w,r,lambda] @
nu=7; 
nz=1;
ns=0;

NewModel("CoRRAM_Test_3.txt",nx,ny,nu,nz,ns);

// Parameters
abar=0.0066;
alpha=0.27;
beta=0.994;
eta=2.0;
delta=0.011;
rhoZ=0.00;
sigmaz=0.0099;
nstar=0.13;

// Stationary solution
astar=exp(abar);
yk=(astar^eta-beta*(1-delta))/(beta*alpha);
kn=astar*(yk^(1/(alpha-1)));
kstar=kn*nstar;
ystar=yk*kstar;
istar=(astar-1+delta)*kstar;
cstar=ystar-istar;
wstar=(1-alpha)*(ystar/nstar);
rstar=alpha*(ystar/kstar);
theta=(wstar/cstar)*(1-nstar);
lstar=(cstar^(-eta))*((1-nstar)^(theta*(1-eta)));

// Definition of variables
_Var[1].name="Output";
_Var[1].type="y";
_Var[1].pos=2;
_Var[1].print=1;
_Var[1].crosscorr=1;
_Var[1].plot=1;
_Var[1].plotno=2;
_Var[1].relsx=1;
_Var[1].xi=1;
_Var[1].star=ystar;

_Var[2].name="Consumption";
_Var[2].type="y";
_Var[2].pos=3;
_Var[2].print=1;
_Var[2].crosscorr=0;
_Var[2].plot=1;
_Var[2].plotno=2;
_Var[2].xi=1;
_Var[2].star=cstar;

_Var[3].name="Investment";
_Var[3].type="y";
_Var[3].pos=4;
_Var[3].print=1;
_Var[3].crosscorr=0;
_Var[3].plot=1;
_Var[3].plotno=2;
_Var[3].xi=1;
_Var[3].star=istar;

_Var[4].name="Hours";
_Var[4].type="y"; 
_Var[4].pos=5;
_Var[4].print=1;  
_Var[4].crosscorr=1; 
_Var[4].plot=1;   
_Var[4].plotno=2;    
_Var[4].xi=0;
_Var[4].star=nstar;

_Var[5].name="Real Wage";
_Var[5].type="y"; 
_Var[5].pos=6;   
_Var[5].print=1;  
_Var[5].crosscorr=0; 
_Var[5].plot=1;   
_Var[5].plotno=3;    
_Var[5].xi=1;
_Var[5].star=wstar;

_Var[6].name="Rental Rate of Capital";
_Var[6].type="y";
_Var[6].pos=7;
_Var[6].print=1;
_Var[6].crosscorr=0;
_Var[6].plot=1;
_Var[6].plotno=3;
_Var[6].xi=0;
_Var[6].star=rstar;

_Var[7].name="Marginal Utility";
_Var[7].type="y";
_Var[7].pos=8;
_Var[7].print=0;
_Var[7].crosscorr=0;
_Var[7].plot=0;
_Var[7].plotno=3;
_Var[7].xi=-eta;
_Var[7].star=lstar;

_Var[8].name="Capital Stock";
_Var[8].type="x";
_Var[8].pos=1;
_Var[8].print=0;
_Var[8].crosscorr=0;
_Var[8].plot=1;
_Var[8].plotno=4;
_Var[8].xi=1;
_Var[8].star=kstar;

_Var[9].name="Growth Factor Shock";
_Var[9].type="z";
_Var[9].pos=1;
_Var[9].print=0;
_Var[9].crosscorr=0;
_Var[9].plot=1;
_Var[9].plotno=1;
_Var[9].star=0;

_Var[10].name="Growth Factor";
_Var[10].type="y";
_Var[10].pos=1;
_Var[10].print=0;
_Var[10].crosscorr=0;
_Var[10].plot=0;
_Var[10].plotno=1;
_Var[10].xi=0;
_Var[10].star=astar;

// Dynamics of the shocks
_Rho[1,1]=RhoZ;
_Omega[1,1]=SigmaZ;
_Sigma=1;

// Solve and simulate the model
retc=SolveModel;
if retc;
    SimulateModel(25,80,300);
endif;

ende:

end;

@ ----------------------------------------------- Procedures --------------------------------------------------- @

// Sys: the model's equations

proc(1)=Sys(w);

  local fx, c1, y1, i1, r1, w1, n1, a1, k1, l1, z1, c2, y2, i2, r2, w2, n2, a2, k2, l2, z2;

  k1=w[1];
  a1=w[2];
  y1=w[3];
  c1=w[4];
  i1=w[5];
  n1=w[6];
  w1=w[7];
  r1=w[8];  
  l1=w[9];
  z1=exp(w[10]);

  k2=w[11];
  a2=w[12];
  y2=w[13];
  c2=w[14];
  i2=w[15];
  n2=w[16];
  w2=w[17];
  r2=w[18];  
  l2=w[19];
  z2=exp(w[20]);

  fx=zeros(_nx+_ny,1);

  fx[1]=(c1^(-eta))*((1-n1)^(theta*(1-eta)))-l1;
  fx[2]=theta*c1-(1-n1)*w1;
  fx[3]=w1-(1-alpha)*(y1/n1);  
  fx[4]=r1-alpha*(y1/k1);
  fx[5]=y1-(a1^(1-alpha))*(n1^(1-alpha))*(k1^alpha);
  fx[6]=y1-c1-i1;
  fx[7]=a1-astar*z1;
  
  fx[8]=a1*k2-(1-delta)*k1 - i1;
  fx[9]=beta*(a1^(-eta))*l2*(1-delta+r2)-l1;

  if _eqno==0; retp(fx); else; retp(fx[_eqno]); endif;
  

  retp(fx);

endp;
