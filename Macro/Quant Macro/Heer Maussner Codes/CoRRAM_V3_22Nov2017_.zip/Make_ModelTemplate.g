@ ----------------------------------------- Make_ModelTemplate.g -----------------------------------------------

    Alfred Maußner
    Revisions: 03 August 2017, first version
               09 October 2017, DS option
               22 November 2017, file name added
               
    Purpose:   Create a template for a DSGE program.
               
    Usage: MakeTemplate(nx,ny,nz,file,DS);
    
    Input: nx, integer, the number of endogenous state variables
           ny, integer, the number of not predetermined variables
           nz, integer, the number of exogenous shocks
           file, string, the name of the output file.
           DS, integer, if DS=1, structure set up for option _DS=1, otherwise DS is ignored
           
    Remarks: This is a stand alone procedure, which can be used at the Gauss prompt.
    
             The procedure addes .g to the string file and saves its results to a file with
             this name in order to ensure color highlighting. For instance, if file="MyModel",
             the results are printed to "MyModel.g".

---------------------------------------------------------------------------------------------------- @

nx=1;
ny=6;
nz=1;
model="SGM_1";
DS=0;

// example use with nx=3, ny=6, and nz=3:

MakeTemplate(nx,ny,nz,model,DS);

end;

@ ------------------------------------ program code of MakeTemplate --------------------------------- @
proc(0)=MakeTemplate(nx,ny,nz,model,DS);
    
    local temp1, temp2,i,j, fn1, fn2;
    
    fn1=model $+".g";
    fn2="file=" $+ "\34" $+ model $+".txt" $+ "\34" $+ ";";
    
    
    temp1="@-------------------------------------------------"
         $+ fn1 $+ 
         " ------------------------------------------------ ";
    j=strlen(temp1);
    temp2="-";
    for i (1,j-2,1);
        temp2=temp2 $+ "-";
    endfor;
    temp2=temp2 $+ " @";
    
    output file=^fn1 reset;
    print temp1;
    print "";
    print " Author: ";
    print MyDate;
    print " Purpose: ";
    print temp2;
    print "";
    print "new;";
    print "library CoRRAM5;";
    print "struct Variable _Var;";
    print "";
    print "// Change default settings";
    print "";
    print "// Create model environment";
    print "";
    if nx<10; temp1="nx=" $+ftos(nx,"-*.*lf",1,0) $+";"; else; temp1="nx=" $+ftos(nx,"-*.*lf",2,0) $+";"; endif;
    print temp1;
    if ny<10; temp1="ny=" $+ftos(ny,"-*.*lf",1,0) $+";"; else; temp1="yx=" $+ftos(ny,"-*.*lf",2,0) $+";"; endif;    
    print temp1;
    temp1="nz=" $+ ftos(nz,"-*.*lf",1,0) $+";";
    print temp1;
    print "nu=;";
    print "ns=0;";
    print fn2;
    print "NewModel(file,nx,ny,nu,nz,ns);";
    print "";
    print "// Parameters";
    print "";
    print "// Stationary Solution";
    print "";
    print "// Define variables";
    MakeVar(nx,ny,nz);
    print "";
    print "// Dynamics of the shocks";
    print "";
    print "// Solve model";
    print "retc=SolveModel;";
    print "";
    print "// Simulate Model";
    print "if retc; SimulateModel(10,80,500); endif;";
    print "";
    print "ende:";
    print "end;";
    print "";
    print "@ --------------------------------------------- Sys: the model's equations ------------------------------ @";
    print "";
    print "proc(1)=Sys(w);";
    print "";
    print "local fx;";
    print "";
    print "fx=ones(_nx+_ny,1);";
    print "";
    print "if _eqno==0; retp(fx); else; retp(fx[_eqno]); endif;";
    print "";
    print "endp;";
    output off;
    retp;
endp;

@ ------------------------------------ program code of MakeVar -------------------------------------- @

proc(0)=MakeVar(nx,ny,nz);
    
    local i, j, str1, str1a, str2, str3, str4, str5, str6, str7, str8, str9, str10, str11, str12;
    
    for i (1,ny,1);
        if i<10;
            str1="_Var[" $+ ftos(i,"-*.*lf",1,0) $+ "]";
            str1a="\34Var" $+ftos(i,"-*.*lf",1,0) $+ "\34;";
            str2=".pos=" $+ ftos(i,"-*.*lf",1,0) $+ ";";
        elseif i<100;
            str1="_Var[" $+ ftos(i,"-*.*lf",2,0) $+ "]";
            str1a="\34Var" $+ ftos(i,"-*.*lf",2,0) $+ "\34;";
            str2=".pos=" $+ ftos(i,"-*.*lf",2,0) $+ ";";
        else;
            str1="_Var[" $+ ftos(i,"-*.*lf",3,0) $+ "]";
            str1a="\34Var" $+ ftos(i,"-*.*lf",3,0) $+ "\34;";
            str2=".pos=" $+ ftos(i,"-*.*lf",3,0) $+ ";";
        endif;
        str3=str1 $+".name=" $+ str1a;
        str4=str1 $+".type=\34y\34;";
        str5=str1 $+ str2;
        str6=str1 $+".print=0;";
        str8=str1 $+".plotno=0;";
        str9=str1 $+".relsx=0;";
        str10=str1 $+".crosscorr=0;";
        str11=str1 $+ ".star=0;";
        str12=str1 $+ ".xi=0;"; 
        ?$str3;
        ?$str4;
        ?$str5;
        ?$str6;
        ?$str8;
        ?$str9;
        ?$str10;
        ?$str11;
        if  DS; ?$str12; endif;
        ?"";
    endfor;
    
    for i (1,nx,1);
        j=ny+i;
        if j<10;
            str1="_Var[" $+ ftos(j,"-*.*lf",1,0) $+ "]";
            str1a="\34Var" $+ ftos(j,"-*.*lf",1,0) $+ "\34;";
        elseif j<100;
            str1="_Var[" $+ ftos(j,"-*.*lf",2,0) $+ "]";
            str1a="\34Var" $+ ftos(j,"-*.*lf",2,0) $+ "\34;";
        else;
            str1="_Var[" $+ ftos(j,"-*.*lf",3,0) $+ "]";
            str1a="\34Var" $+ ftos(j,"-*.*lf",3,0) $+ "\34;";
        endif;
        if i<10;            
            str2=".pos=" $+ ftos(i,"-*.*lf",1,0) $+ ";";
        elseif i<100;            
            str2=".pos=" $+ ftos(i,"-*.*lf",2,0) $+ ";";
        else;
            str2=".pos=" $+ ftos(i,"-*.*lf",3,0) $+ ";";
        endif;            
        str3=str1 $+".name=" $+ str1a;
        str4=str1 $+".type=\34x\34;";
        str5=str1 $+ str2;
        str6=str1 $+".print=0;";
        str8=str1 $+".plotno=0;";
        str9=str1 $+".relsx=0;";        
        str10=str1 $+".crosscorr=0;";
        str11=str1 $+ ".star=0;";
        str12=str1 $+ ".xi=0;";
        ?$str3;
        ?$str4;
        ?$str5;
        ?$str6;
        ?$str8;
        ?$str9;
        ?$str10;
        ?$str11;
        if DS; ?$str12; endif;
        ?"";
    endfor;
    
    for i (1,nz,1);
        j=ny+nx+i;        
        if j<10;
            str1="_Var[" $+ ftos(j,"-*.*lf",1,0) $+ "]";
            str1a="\34Var" $+ ftos(j,"-*.*lf",1,0) $+ "\34;";
        elseif j<100;
            str1="_Var[" $+ ftos(j,"-*.*lf",2,0) $+ "]";
            str1a="\34Var" $+ ftos(j,"-*.*lf",2,0) $+ "\34;";
        else;
            str1="_Var[" $+ ftos(j,"-*.*lf",3,0) $+ "]";
            str1a="\34Var" $+ ftos(j,"-*.*lf",3,0) $+ "\34;";
        endif;        
        if i<10;            
            str2=".pos=" $+ ftos(i,"-*.*lf",1,0) $+ ";";
        elseif i<100;            
            str2=".pos=" $+ ftos(i,"-*.*lf",2,0) $+ ";";
        else;
            str2=".pos=" $+ ftos(i,"-*.*lf",3,0) $+ ";";
        endif;            
        str3=str1 $+".name=" $+ str1a;
        str4=str1 $+".type=\34z\34;";
        str5=str1 $+ str2;
        str6=str1 $+".print=0;";
        str8=str1 $+".plotno=0;";
        str9=str1 $+".relsx=0;";
        str10=str1 $+ ".star=0;";
        ?$str3;
        ?$str4;
        ?$str5;
        ?$str6;
        ?$str8;
        ?$str9;
        ?$str10;
        ?"";
    endfor;
        
    
    retp;
    
endp;

proc(1)=MyDate;

  local d, str1, month;
  
  month="January"$|"February"$|"March"$|"April"$|"May"$|"June"$|"July"$|"August"$|"September"$|"October"$|
        "November"$|"December";

  d=date;  
  str1=" " $+ ftos(d[3],"%0*.*lf",2,0) $+ " " $+ month[d[2]] $+" " $+ ftos(d[1],"%0*.*lf",2,0);

retp(str1);

endp;
