@ ---------------------------------------- CoRRAM_Test_2.g ---------------------------------

    Alfred Maussner
    Revisons: 01 October  2013, first version
              20 April    2017, adapted to CoRRAM version 5

    Purpose: Test the new CoRRAM toolbox. Here I use the _GSchur=1 option.

------------------------------------------------------------------------------------------- @

/* Do not change the next lines of code: *************/
new;
library corram;
struct Variable _Var;

/*****************************************************/    

// Change defaul settings
_GaussOnly=1;
_GSchur=0;
_loadShocks=0;
_TrendLine=0;
_linear=0;

// Create model environment
nx=1;
ny=7;
nu=6;
nz=1;
ns=0;
outfile="CoRRAM_Test_2.txt";

NewModel(outfile,nx,ny,nu,nz,ns);

// Parameters
a=1.005;
alpha=0.27;
beta=0.994;
eta=2.0;
delta=0.011;
rhoZ=0.90;
sigmaz=0.0072;
nstar=0.13;

// Compute the stationary solution 
yk=(a^eta-beta*(1-delta))/(beta*alpha);
ck=yk+(1-a-delta);
theta = (1-alpha)*(yk/ck)*(1-nstar)*(1/nstar);
kn=yk^(1/(alpha-1));
kstar=kn*nstar;
ystar=yk*kstar;
cstar=ck*kstar;
istar=ystar-cstar;
wstar=(1-alpha)*(ystar/nstar);
rstar=alpha*yk;
lstar=(cstar^(-eta))*((1-nstar)^(theta*(1-eta)));

// Define variables

_Var[1].name="Output";
_Var[1].type="y";
_Var[1].pos=1;
_Var[1].print=1;
_Var[1].crosscorr=1;
_Var[1].plot=1;
_Var[1].plotno=2;
_Var[1].relsx=1;
_Var[1].star=ystar;

_Var[2].name="Consumption";
_Var[2].type="y";
_Var[2].pos=2;
_Var[2].print=1;
_Var[2].crosscorr=0;
_Var[2].plot=1;
_Var[2].plotno=2;
_Var[2].star=cstar;

_Var[3].name="Investment";
_Var[3].type="y";
_Var[3].pos=3;
_Var[3].print=1;
_Var[3].crosscorr=0;
_Var[3].plot=1;
_Var[3].plotno=2;
_Var[3].star=istar;

_Var[4].name="Hours";
_Var[4].type="y"; 
_Var[4].pos=4;  
_Var[4].print=1;  
_Var[4].crosscorr=0; 
_Var[4].plot=1;   
_Var[4].plotno=2;    
_Var[4].star=nstar;

_Var[5].name="Real Wage";
_Var[5].type="y"; 
_Var[5].pos=5;   
_Var[5].print=1;  
_Var[5].crosscorr=1; 
_Var[5].plot=1;   
_Var[5].plotno=3;    
_Var[5].star=wstar;

_Var[6].name="User Costs of Capital";
_Var[6].type="y";
_Var[6].pos=6;
_Var[6].print=1;
_Var[6].crosscorr=0;
_Var[6].plot=1;
_Var[6].plotno=3;
_Var[6].star=rstar;
    
_Var[7].name="Marginal Utility";
_Var[7].type="y";
_Var[7].pos=7;
_Var[7].print=1;
_Var[7].crosscorr=0;
_Var[7].plot=1;
_Var[7].plotno=3;
_Var[7].star=lstar;

_Var[8].name="Capital Stock";
_Var[8].type="x";
_Var[8].pos=1;
_Var[8].print=0;
_Var[8].crosscorr=0;
_Var[8].plot=1;
_Var[8].plotno=4;
_Var[8].star=kstar;

_Var[9].name="TFP Shock";
_Var[9].type="z";
_Var[9].pos=1;
_Var[9].print=0;
_Var[9].crosscorr=0;
_Var[9].plot=1;
_Var[9].plotno=1;

// Dynamics of the shock
_Rho[1,1]=RhoZ;
_Omega[1,1]=SigmaZ;
_Sigma=1;

// Solve model
retc=SolveModel;

// simulate model
if retc;
    SimulateModel(25,80,500);
endif;

ende:

end;

@ ----------------------------------------------------------------- Procedures ------------------------------------------------------ @

// Sys: the model's equations

proc(1)=Sys(w);

  local fx, c1, y1, i1, r1,w1,n1, k1, l1, z1, c2, y2, i2, r2,w2,n2, k2, l2, z2;

  k1=w[1];
  y1=w[2];
  c1=w[3];
  i1=w[4];
  n1=w[5];
  w1=w[6];
  r1=w[7];
  l1=w[8];
  z1=exp(w[9]);

  k2=w[10];
  y2=w[11];
  c2=w[12];
  i2=w[13];
  n2=w[14];
  w2=w[15];
  r2=w[16];
  l2=w[17];
  z2=exp(w[18]);

  fx=zeros(_nx+_ny,1);

  fx[1]=(c1^(-eta))*((1-n1)^(theta*(1-eta)))-l1;
  fx[2]=theta*(c1^(1-eta))*((1-n1)^(theta*(1-eta)-1))-w1*l1;
  fx[3]=w1-(1-alpha)*z1*(n1^(-alpha))*(k1^alpha);
  fx[4]=r1-alpha*z1*(n1^(1-alpha))*(k1^(alpha-1));
  fx[5]=y1-z1*(n1^(1-alpha))*(k1^alpha);
  fx[6]=y1-c1-i1;

  fx[7]=a*k2-(1-delta)*k1 - i1;
  fx[8]=beta*(a^(-eta))*l2*(1-delta+r2)-l1;

  if _eqno==0; retp(fx); else; retp(fx[_eqno]); endif;
  

    retp(fx);

endp;
