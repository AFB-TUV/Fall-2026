@ ----------------------------------- LU_Test.g ---------------------------------------------------------

    Alfred Maußner
    17 December 2015
    
    Purpose: test the LU factorization with the matrices a_LU and b_LU.
    
--------------------------------------------------------------------------------------------------------- @

new;
load a_LU, b_LU;

xmat_LU=LSolve(a_LU,b_LU);
print xmat_LU;

end;


@ ---------------------------- LSolve ----------------------------------------------------------

  Alfred Maußner
  
  28 April 2014
  
  Previously I used LSolve to solve a system of linear equations Ax=b via the LU-decomposition.
  
  A reader of our book sent us a mail with an advice from an Aptech service person, saying
  
  "The GAUSS "/" operator will perform an LU decomposition based solve.
   It will be faster and as accurate or more."
  
  However, when I applied x=b/A (and, therefore, recoded LU to return b/A)
  to complex systems, I got wrong results. Thus, I still use LSolve in its original
  code.
------------------------------------------------------------------------------------ @
/* LSolve:
**
**  Purpose: Solve a system of linear equations Ax=b using the LU-decomposition
**
**  Usage:  x=LSolve(A,b)
**
**  Input:  A: square matrix of dimension n
**          b: matrix of  dimension n by m (m the number of equations to solve)
**
**  Output: x: matrix of dimension  n by m
*/   

proc(1)=LSolve(a,b);

	local l, u;
	{l,u}=LU(a); 
	retp(LUSol(b,l,u));
    
endp;
