@ ----------------------------------------- MakeVar_5.g -----------------------------------------------

    Alfred Maußner
    Revisions: 17 July 2017, first version
    Purpose:   write an instance of the _var structure with initial settings to
               an ASCII file which can be used to define the variables of a model
               and saves typing effort.
               
    Usage: MakeVar(nx,ny,nz,file);
    
    Input: nx, integer, the number of endogenous state variables
           ny, integer, the number of not predetermined variables
           nz, integer, the number of exogenous shocks
           file, string, the name of the output file.
           
    Remarks: This is a stand alone procedure, which can be used at the Gauss prompt.
    
             Give the string in file the ending .g to ensure color highlighting, as for instance,
             file="MyModel.g"

---------------------------------------------------------------------------------------------------- @

// example use with nx=3, ny=6, and nz=3:

MakeVar(3,6,2,"MyModel.g");

end;

@ ------------------------------------ program code of MakeVar -------------------------------------- @

proc(0)=MakeVar(nx,ny,nz,file);
    
    local i, j, str1, str1a, str2, str3, str4, str5, str6, str7, str8, str9, str10;
    
    output file=^file reset;
    
    for i (1,ny,1);
        if i<10;
            str1="_Var[" $+ ftos(i,"-*.*lf",1,0) $+ "]";
            str1a="\34Var" $+ftos(i,"-*.*lf",1,0) $+ "\34;";
            str2=".pos=" $+ ftos(i,"-*.*lf",1,0) $+ ";";
        elseif i<100;
            str1="_Var[" $+ ftos(i,"-*.*lf",2,0) $+ "]";
            str1a="\34Var" $+ ftos(i,"-*.*lf",2,0) $+ "\34;";
            str2=".pos=" $+ ftos(i,"-*.*lf",2,0) $+ ";";
        else;
            str1="_Var[" $+ ftos(i,"-*.*lf",3,0) $+ "]";
            str1a="\34Var" $+ ftos(i,"-*.*lf",3,0) $+ "\34;";
            str2=".pos=" $+ ftos(i,"-*.*lf",3,0) $+ ";";
        endif;
        str3=str1 $+".name=" $+ str1a;
        str4=str1 $+".type=\34y\34;";
        str5=str1 $+ str2;
        str6=str1 $+".print=0;";
        str8=str1 $+".plotno=0;";
        str9=str1 $+".relsx=0;";
        str10=str1 $+ ".star=0;";
        ?$str3;
        ?$str4;
        ?$str5;
        ?$str6;
        ?$str8;
        ?$str9;
        ?$str10;
        ?"";
    endfor;
    
    for i (1,nx,1);
        j=ny+i;
        if j<10;
            str1="_Var[" $+ ftos(j,"-*.*lf",1,0) $+ "]";
            str1a="\34Var" $+ ftos(j,"-*.*lf",1,0) $+ "\34;";
        elseif j<100;
            str1="_Var[" $+ ftos(j,"-*.*lf",2,0) $+ "]";
            str1a="\34Var" $+ ftos(j,"-*.*lf",2,0) $+ "\34;";
        else;
            str1="_Var[" $+ ftos(j,"-*.*lf",3,0) $+ "]";
            str1a="\34Var" $+ ftos(j,"-*.*lf",3,0) $+ "\34;";
        endif;
        if i<10;            
            str2=".pos=" $+ ftos(i,"-*.*lf",1,0) $+ ";";
        elseif i<100;            
            str2=".pos=" $+ ftos(i,"-*.*lf",2,0) $+ ";";
        else;
            str2=".pos=" $+ ftos(i,"-*.*lf",3,0) $+ ";";
        endif;            
        str3=str1 $+".name=" $+ str1a;
        str4=str1 $+".type=\34x\34;";
        str5=str1 $+ str2;
        str6=str1 $+".print=0;";
        str8=str1 $+".plotno=0;";
        str9=str1 $+".relsx=0;";
        str10=str1 $+ ".star=0;";
        ?$str3;
        ?$str4;
        ?$str5;
        ?$str6;
        ?$str8;
        ?$str9;
        ?$str10;
        ?"";
    endfor;
    
    for i (1,nz,1);
        j=ny+nx+i;        
        if j<10;
            str1="_Var[" $+ ftos(j,"-*.*lf",1,0) $+ "]";
            str1a="\34Var" $+ ftos(j,"-*.*lf",1,0) $+ "\34;";
        elseif j<100;
            str1="_Var[" $+ ftos(j,"-*.*lf",2,0) $+ "]";
            str1a="\34Var" $+ ftos(j,"-*.*lf",2,0) $+ "\34;";
        else;
            str1="_Var[" $+ ftos(j,"-*.*lf",3,0) $+ "]";
            str1a="\34Var" $+ ftos(j,"-*.*lf",3,0) $+ "\34;";
        endif;        
        if i<10;            
            str2=".pos=" $+ ftos(i,"-*.*lf",1,0) $+ ";";
        elseif i<100;            
            str2=".pos=" $+ ftos(i,"-*.*lf",2,0) $+ ";";
        else;
            str2=".pos=" $+ ftos(i,"-*.*lf",3,0) $+ ";";
        endif;            
        str3=str1 $+".name=" $+ str1a;
        str4=str1 $+".type=\34z\34;";
        str5=str1 $+ str2;
        str6=str1 $+".print=0;";
        str8=str1 $+".plotno=0;";
        str9=str1 $+".relsx=0;";
        str10=str1 $+ ".star=0;";
        ?$str3;
        ?$str4;
        ?$str5;
        ?$str6;
        ?$str8;
        ?$str9;
        ?$str10;
        ?"";
    endfor;
    output off; 
        
    
    retp;
    
endp;
