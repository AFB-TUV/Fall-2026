@ ---------------------------------------- CoRRAM_Test_1.g -----------------------------------------

    Alfred Maussner
    Revisions: 28 November 2012, first version
               20 April    2017, adapted to CoRRAM5

    Purpose: Test the new CoRRAM5 toolbox.

--------------------------------------------------------------------------------------------------- @

/* Do not change the next lines of code: *************/

new;
library CoRRAM;
struct Variable _Var;

/*****************************************************/    

// Change default settings
_equations=0;

// Create a new model
nx=1;
ny=8;
nu=6;
nz=1;
ns=1;

NewModel("CoRRAM_Test_1.txt",nx,ny,nu,nz,ns);

// Parameters
@ First Part @
a=1.005;
alpha=0.27;
beta=0.994;
eta=2.0;
delta=0.011;
rhoZ=0.90;
sigmaz=0.0072;
nstar=0.13;

// Compute the stationary solution 
yk=(a^eta-beta*(1-delta))/(beta*alpha);
ck=yk+(1-a-delta);
theta = (1-alpha)*(yk/ck)*(1-nstar)*(1/nstar);


// Define variables and determine output options

_Var[1].name="Output";
_Var[1].type="y";
_Var[1].pos=1;
_Var[1].print=1;
_Var[1].crosscorr=1;
_Var[1].plotno=2;
_Var[1].relsx=1;

_Var[2].name="Consumption";
_Var[2].type="y";
_Var[2].pos=2;
_Var[2].print=1;
_Var[2].crosscorr=0;
_Var[2].plotno=2;

_Var[3].name="Investment";
_Var[3].type="y";
_Var[3].pos=3;
_Var[3].print=1;
_Var[3].crosscorr=0;
_Var[3].plotno=2;

_Var[4].name="Hours";
_Var[4].type="y"; 
_Var[4].pos=4;  
_Var[4].print=1;  
_Var[4].crosscorr=0;
_Var[4].plotno=2;    

_Var[5].name="Real Wage";
_Var[5].type="y"; 
_Var[5].pos=5;   
_Var[5].print=1;  
_Var[5].crosscorr=1;
_Var[5].plotno=3;    

_Var[6].name="User Costs of Capital";
_Var[6].type="y";
_Var[6].pos=6;
_Var[6].print=1;
_Var[6].crosscorr=0;
_Var[6].plotno=3;
    
_Var[7].name="Marginal Utility";
_Var[7].type="y";
_Var[7].pos=7;
_Var[7].print=1;
_Var[7].crosscorr=0;
_Var[7].plotno=0;

_Var[8].name="Bond Price";
_Var[8].type="y";
_Var[8].pos=8;
_Var[8].print=1;
_Var[8].crosscorr=0;
_Var[8].plotno=3;


_Var[9].name="Capital Stock";
_Var[9].type="x";
_Var[9].pos=1;
_Var[9].print=0;
_Var[9].crosscorr=0;
_Var[9].plotno=4;

_Var[10].name="TFP Shock";
_Var[10].type="z";
_Var[10].pos=1;
_Var[10].print=0;
_Var[10].crosscorr=0;
_Var[10].plotno=1;

// Dynamics of the shock
_Rho[1,1]=RhoZ;
_Omega[1,1]=SigmaZ;
_Sigma=1;

// input the matrices of the log-linear version
 _Cu[1,2]=-eta;
 _Cu[1,4]=-theta*(1-eta)*(nstar/(1-nstar));
_Cxl[1,2]=1;

/* Equation 3.4.b */
 _Cu[2,2]=1-eta;
 _Cu[2,4]=-(theta*(1-eta)-1)*(nstar/(1-nstar));
 _Cu[2,5]=-1;
_Cxl[2,2]=1;

/* Equation 3.4.c */
 _Cu[3,1]=-1;
 _Cu[3,6]=1;
_Cxl[3,1]=-1;


/* Equation 3.4.d */
 _Cu[4,1]=-1;
 _Cu[4,4]=1;
 _Cu[4,5]=1;

/* Equation 3.4.e */
 _Cu[5,1]=1;
 _Cu[5,4]=alpha-1;
_Cxl[5,1]=alpha;
 _Cz[5,1]=1;

/* Equation 3.4.f */
 _Cu[6,1]=1;
 _Cu[6,2]=-(ck/yk);
 _Cu[6,3]=-(a-1+delta)/yk;
 

/* Equation 3.4.g */
_Dxl[1,1]=a;
_Fxl[1,1]=delta-1;
 _Fu[1,3]=delta+a-1;

/* Equation 3.4.h */
_Dxl[2,2]=1;
_Fxl[2,2]=-1;
 _Du[2,6]=-(1-beta*(a^(-eta))*(1-delta));


// Solve the model
retc=SolveModel;

// Simulate the model
if retc;
    /* if your model includes additional variables, _ns>0, you must input Lsx and Lsz here: */
    /* According to the numbering, lambda is the 7th variable in the vector y */
    _Lsx=_Lyx[7,.]*(_Lxx-eye(_nx));
    _Lsz=_Lyx[7,.]*_Lxz+_Lyz[7,.]*(_Rho-Eye(_nz));
    SimulateModel(10,80,500);
endif;

ende:

end;

// Dummy definition of Sys

proc(1)=Sys(w);

  local fx;

  fx=zeros(_nx+_ny,1);

  if _eqno==0; retp(fx); else; retp(fx[_eqno]); endif;
  retp(fx);


endp;
